// Aadhaar & Voter Card Print Compiler

document.addEventListener('DOMContentLoaded', () => {
    const frontInput = document.getElementById('aadhaar-front');
    const backInput = document.getElementById('aadhaar-back');
    const frontZone = document.getElementById('aadhaar-front-zone');
    const backZone = document.getElementById('aadhaar-back-zone');
    const frontName = document.getElementById('aadhaar-front-name');
    const backName = document.getElementById('aadhaar-back-name');

    const layoutType = document.getElementById('aadhaar-layout-type');
    const scaleSlider = document.getElementById('aadhaar-scale');
    const scaleVal = document.getElementById('aadhaar-scale-val');
    const contrastSlider = document.getElementById('aadhaar-contrast');
    const contrastVal = document.getElementById('aadhaar-contrast-val');

    const canvas = document.getElementById('aadhaar-canvas');
    const ctx = canvas.getContext('2d');
    const downloadBtn = document.getElementById('download-aadhaar');
    const printBtn = document.getElementById('print-aadhaar');

    let frontImg = null;
    let backImg = null;

    // Handle Drag & Drop styles
    [frontZone, backZone].forEach(zone => {
        zone.addEventListener('dragover', (e) => {
            e.preventDefault();
            zone.style.borderColor = 'var(--primary)';
            zone.style.background = 'rgba(99, 102, 241, 0.08)';
        });

        zone.addEventListener('dragleave', () => {
            zone.style.borderColor = 'var(--border-color)';
            zone.style.background = 'rgba(0, 0, 0, 0.05)';
        });
    });

    // Handle File Uploads
    frontInput.addEventListener('change', (e) => handleFile(e.target.files[0], 'front'));
    backInput.addEventListener('change', (e) => handleFile(e.target.files[0], 'back'));

    function handleFile(file, side) {
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
                if (side === 'front') {
                    frontImg = img;
                    frontName.textContent = file.name;
                } else {
                    backImg = img;
                    backName.textContent = file.name;
                }
                drawLayout();
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
    }

    // Sliders & Select Controls
    scaleSlider.addEventListener('input', (e) => {
        scaleVal.textContent = e.target.value + '%';
        drawLayout();
    });

    contrastSlider.addEventListener('input', (e) => {
        contrastVal.textContent = e.target.value + '%';
        drawLayout();
    });

    layoutType.addEventListener('change', () => {
        drawLayout();
    });

    // Drawing Logic
    function drawLayout() {
        const layout = layoutType.value;
        const scale = scaleSlider.value / 100;
        const contrast = contrastSlider.value;

        // Clear Canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Adjust Canvas Size according to Layout Mode
        if (layout === 'id-card') {
            canvas.width = 1000;
            canvas.height = 420;
        } else {
            // A4 document size representation
            canvas.width = 650;
            canvas.height = 920;
        }

        // Draw White Background for Prints
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Define card proportions
        // Standard ID Card aspect ratio is roughly 8.5 x 5.5.
        // We render it at 400px x 256px base size.
        const baseWidth = 400;
        const baseHeight = 256;

        const w = baseWidth * scale;
        const h = baseHeight * scale;

        // Apply contrast filter to image draw operations
        ctx.filter = `contrast(${contrast}%)`;

        if (layout === 'id-card') {
            // Layout: Side-by-Side with 40px spacing
            const gap = 40;
            const startX = (canvas.width - (w * 2 + gap)) / 2;
            const startY = (canvas.height - h) / 2;

            // Draw Front
            if (frontImg) {
                ctx.drawImage(frontImg, startX, startY, w, h);
            } else {
                drawPlaceholder(startX, startY, w, h, 'Upload Front Side');
            }

            // Draw Back
            if (backImg) {
                ctx.drawImage(backImg, startX + w + gap, startY, w, h);
            } else {
                drawPlaceholder(startX + w + gap, startY, w, h, 'Upload Back Side');
            }

            // Reset filters to draw border overlays
            ctx.filter = 'none';

            // Draw clean borders / cut indicators
            drawBorder(startX, startY, w, h);
            drawBorder(startX + w + gap, startY, w, h);

        } else {
            // Layout: A4 Stacked (front top, back bottom)
            const gap = 60;
            const startX = (canvas.width - w) / 2;
            const startY = (canvas.height - (h * 2 + gap)) / 2;

            // Draw Front
            if (frontImg) {
                ctx.drawImage(frontImg, startX, startY, w, h);
            } else {
                drawPlaceholder(startX, startY, w, h, 'Upload Front Side');
            }

            // Draw Back
            if (backImg) {
                ctx.drawImage(backImg, startX, startY + h + gap, w, h);
            } else {
                drawPlaceholder(startX, startY + h + gap, w, h, 'Upload Back Side');
            }

            // Reset Filters
            ctx.filter = 'none';

            // Draw Borders
            drawBorder(startX, startY, w, h);
            drawBorder(startX, startY + h + gap, w, h);
        }
    }

    function drawPlaceholder(x, y, w, h, text) {
        ctx.fillStyle = '#f9fafb';
        ctx.fillRect(x, y, w, h);
        
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.strokeRect(x, y, w, h);
        ctx.setLineDash([]);

        ctx.fillStyle = '#64748b';
        ctx.font = 'bold 14px "Outfit", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, x + w / 2, y + h / 2);
    }

    function drawBorder(x, y, w, h) {
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]); // Dashed line to show cut markings
        ctx.strokeRect(x, y, w, h);
        ctx.setLineDash([]);
    }

    // Initialize Canvas Placeholder on load
    drawLayout();

    // Download Handler
    downloadBtn.addEventListener('click', () => {
        if (!frontImg && !backImg) {
            alert('Please upload at least one side of the ID card.');
            return;
        }
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
        const link = document.createElement('a');
        link.download = 'CSC-ID-Card-Print.jpg';
        link.href = dataUrl;
        link.click();
        
        if (window.incrementProcessedCount) window.incrementProcessedCount();
    });

    // Print Handler
    printBtn.addEventListener('click', () => {
        if (!frontImg && !backImg) {
            alert('Please upload at least one side of the ID card.');
            return;
        }

        const dataUrl = canvas.toDataURL('image/png');
        const printArea = document.getElementById('printable-area');
        
        printArea.innerHTML = `
            <div class="print-sheet-layout">
                <img src="${dataUrl}" style="width: ${layoutType.value === 'id-card' ? '180mm' : '150mm'}; border: none;">
            </div>
        `;

        window.print();
        
        if (window.incrementProcessedCount) window.incrementProcessedCount();
    });
});
