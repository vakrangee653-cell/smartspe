// CSP Manager, Ledger & Dues Controller

document.addEventListener('DOMContentLoaded', () => {
    // Date input elements
    const txDateInput = document.getElementById('tx-date');
    const custDateInput = document.getElementById('cust-date');
    const qTxDateInput = document.getElementById('q-tx-date');
    const qCustDateInput = document.getElementById('q-cust-date');

    // Filter elements
    const searchLedgerInput = document.getElementById('search-ledger-input');
    const ledgerStartDateInput = document.getElementById('ledger-start-date');
    const ledgerEndDateInput = document.getElementById('ledger-end-date');

    const custStartDateInput = document.getElementById('cust-start-date');
    const custEndDateInput = document.getElementById('cust-end-date');

    // Helper to get local date ISO string YYYY-MM-DD
    function getLocalISODate(dateObj = new Date()) {
        const year = dateObj.getFullYear();
        const month = String(dateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dateObj.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Default form dates to today
    const todayISO = getLocalISODate();
    if (txDateInput) txDateInput.value = todayISO;
    if (custDateInput) custDateInput.value = todayISO;
    if (qTxDateInput) qTxDateInput.value = todayISO;
    if (qCustDateInput) qCustDateInput.value = todayISO;
    const walletTopupDateInput = document.getElementById('wallet-topup-date');
    if (walletTopupDateInput) walletTopupDateInput.value = todayISO;

    // 1. CSP internal tab switching
    const tabButtons = document.querySelectorAll('#panel-csp .form-tab');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            tabButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const targetTabId = btn.getAttribute('data-tab');
            const subTabs = document.querySelectorAll('#panel-csp .tab-content');
            subTabs.forEach(tab => {
                tab.style.display = 'none';
            });

            document.getElementById(targetTabId).style.display = 'flex';
        });
    });

    // 2. Default Service Rates Catalog
    const defaultRates = [
        { id: '1', name: 'PAN Card Apply', category: 'Government', govtFee: 107, customerFee: 157, netMargin: 50 },
        { id: '2', name: 'Aadhaar Update', category: 'Government', govtFee: 50, customerFee: 80, netMargin: 30 },
        { id: '3', name: 'Voter ID Apply', category: 'Government', govtFee: 0, customerFee: 40, netMargin: 40 },
        { id: '4', name: 'Ayushman Card', category: 'Government', govtFee: 0, customerFee: 60, netMargin: 60 },
        { id: '5', name: 'Electricity Bill', category: 'Recharge', govtFee: 0, customerFee: 20, netMargin: 20 },
        { id: '6', name: 'Bank CSP Withdrawal', category: 'Banking', govtFee: 0, customerFee: 10, netMargin: 10 },
        { id: '7', name: 'Insurance Premium', category: 'Insurance', govtFee: 0, customerFee: 100, netMargin: 100 },
        { id: '8', name: 'Mobile Recharge', category: 'Recharge', govtFee: 0, customerFee: 10, netMargin: 10 },
        { id: '9', name: 'DTH Recharge', category: 'Recharge', govtFee: 0, customerFee: 10, netMargin: 10 },
        { id: '10', name: 'Aadhaar Print & Laminate', category: 'Government', govtFee: 0, customerFee: 30, netMargin: 30 },
        { id: '11', name: 'Voter Print & Laminate', category: 'Government', govtFee: 0, customerFee: 30, netMargin: 30 },
        { id: '12', name: 'Passport Size Photo (8 Copies)', category: 'Government', govtFee: 0, customerFee: 50, netMargin: 50 },
        { id: '13', name: 'Resume & Job Biodata', category: 'Government', govtFee: 0, customerFee: 50, netMargin: 50 },
        { id: '14', name: 'Income Certificate Apply', category: 'Government', govtFee: 15, customerFee: 60, netMargin: 45 },
        { id: '15', name: 'Caste Certificate Apply', category: 'Government', govtFee: 15, customerFee: 60, netMargin: 45 },
        { id: '16', name: 'Domicile Certificate Apply', category: 'Government', govtFee: 15, customerFee: 60, netMargin: 45 },
        { id: '17', name: 'Pension Scheme Registration', category: 'Government', govtFee: 0, customerFee: 50, netMargin: 50 },
        { id: '18', name: 'Police Verification Apply', category: 'Government', govtFee: 50, customerFee: 100, netMargin: 50 },
        { id: '19', name: 'Driving Licence Service', category: 'Government', govtFee: 150, customerFee: 250, netMargin: 100 },
        { id: '20', name: 'New Ration Card Apply', category: 'Government', govtFee: 20, customerFee: 100, netMargin: 80 },
        { id: '21', name: 'PM Kisan Registration', category: 'Government', govtFee: 0, customerFee: 50, netMargin: 50 },
        { id: '22', name: 'E-Shram Card Registration', category: 'Government', govtFee: 0, customerFee: 40, netMargin: 40 },
        { id: '23', name: 'Bank Account Opening', category: 'Banking', govtFee: 0, customerFee: 100, netMargin: 100 }
    ];

    // Load arrays from localStorage or set defaults
    let transactions = JSON.parse(localStorage.getItem('csc_csp_transactions') || '[]');
    let customers = JSON.parse(localStorage.getItem('csc_csp_customers') || '[]');
    let serviceRates = JSON.parse(localStorage.getItem('csc_csp_rates') || '[]');
    let walletTransactions = JSON.parse(localStorage.getItem('csc_wallet_transactions') || '[]');

    // Auto-migrate: assign custNo to existing customers if missing
    let migrated = false;
    let nextCustNo = 1001;
    const existingNos = customers.map(c => c.custNo).filter(n => typeof n === 'number');
    if (existingNos.length > 0) {
        nextCustNo = Math.max(...existingNos) + 1;
    }
    for (let i = customers.length - 1; i >= 0; i--) {
        if (!customers[i].custNo) {
            customers[i].custNo = nextCustNo++;
            migrated = true;
        }
    }
    if (migrated) {
        localStorage.setItem('csc_csp_customers', JSON.stringify(customers));
    }

    if (!serviceRates || !Array.isArray(serviceRates) || serviceRates.length === 0 || !serviceRates[0] || !serviceRates[0].category) {
        serviceRates = [...defaultRates];
        localStorage.setItem('csc_csp_rates', JSON.stringify(serviceRates));
    } else {
        // Migration: check if any defaultRate is missing in the user's stored serviceRates, and add it
        let updated = false;
        defaultRates.forEach(dRate => {
            const exists = serviceRates.some(r => r.id === dRate.id || r.name.toLowerCase() === dRate.name.toLowerCase());
            if (!exists) {
                serviceRates.push(dRate);
                updated = true;
            }
        });
        if (updated) {
            localStorage.setItem('csc_csp_rates', JSON.stringify(serviceRates));
        }
    }

    // 3. Transactions / Ledger Handlers
    const saveTxBtn = document.getElementById('save-tx-btn');
    const txTypeSelect = document.getElementById('tx-type');
    const txAmountInput = document.getElementById('tx-amount');
    const txModeSelect = document.getElementById('tx-mode');
    const txCategorySelect = document.getElementById('tx-category');
    const txDescInput = document.getElementById('tx-desc');
    const ledgerTableBody = document.getElementById('ledger-table-body');

    // Stats indicators
    const incomeStat = document.getElementById('ledger-income-stat');
    const expenseStat = document.getElementById('ledger-expense-stat');
    const balanceStat = document.getElementById('ledger-balance-stat');

    function saveTransactions() {
        localStorage.setItem('csc_csp_transactions', JSON.stringify(transactions));
        loadLedger();
    }

    function addTransactionDirectly(type, category, amount, mode, desc, customIsoDate = null) {
        const isoDate = customIsoDate || getLocalISODate();
        
        let formattedDate;
        if (customIsoDate) {
            const parts = customIsoDate.split('-');
            const dObj = new Date(parts[0], parts[1] - 1, parts[2]);
            formattedDate = dObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
        } else {
            formattedDate = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
        }

        const newTx = {
            id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
            date: formattedDate,
            isoDate: isoDate,
            type,
            category,
            amount: parseFloat(amount) || 0,
            mode,
            desc: desc || '-'
        };
        transactions.unshift(newTx);
        saveTransactions();
    }

    if (saveTxBtn) {
        saveTxBtn.addEventListener('click', () => {
            const amount = parseFloat(txAmountInput.value);
            if (!amount || amount <= 0) {
                alert('Please enter a valid amount.');
                return;
            }

            const type = txTypeSelect.value;
            const category = txCategorySelect.value;
            const mode = txModeSelect.value;
            const desc = txDescInput.value.trim();
            const customTxDate = txDateInput ? txDateInput.value : '';
            const linkId = Date.now().toString() + Math.random().toString(36).substr(2, 5);

            addTransactionDirectly(type, category, amount, mode, desc, customTxDate);

            // Link it
            if (transactions.length > 0) {
                transactions[0].id = linkId;
                saveTransactions();
            }


            // Reset inputs
            txAmountInput.value = '';
            txDescInput.value = '';
            if (txDateInput) txDateInput.value = getLocalISODate();

            if (window.incrementProcessedCount) window.incrementProcessedCount();
        });
    }

    function loadLedger() {
        // Reload transactions and wallet transactions from localStorage to sync updates
        transactions = JSON.parse(localStorage.getItem('csc_csp_transactions') || '[]');
        walletTransactions = JSON.parse(localStorage.getItem('csc_wallet_transactions') || '[]');

        const searchQuery = searchLedgerInput ? searchLedgerInput.value.toLowerCase().trim() : '';
        const startDate = ledgerStartDateInput ? ledgerStartDateInput.value : '';
        const endDate = ledgerEndDateInput ? ledgerEndDateInput.value : '';

        // Filter the transactions
        const filteredTxs = transactions.filter(tx => {
            if (searchQuery) {
                const cat = tx.category.toLowerCase();
                const desc = tx.desc.toLowerCase();
                if (!cat.includes(searchQuery) && !desc.includes(searchQuery)) {
                    return false;
                }
            }

            const txIso = tx.isoDate || getLocalISODate();
            if (startDate && txIso < startDate) return false;
            if (endDate && txIso > endDate) return false;

            return true;
        });

        let totalIncome = 0;
        let totalExpense = 0;

        filteredTxs.forEach(tx => {
            if (tx.type === 'income') {
                totalIncome += tx.amount;
            } else {
                totalExpense += tx.amount;
            }
        });

        // Update UI counters (filtered)
        incomeStat.textContent = `₹${totalIncome.toFixed(2)}`;
        expenseStat.textContent = `₹${totalExpense.toFixed(2)}`;
        
        const balance = totalIncome - totalExpense;
        balanceStat.textContent = `₹${balance.toFixed(2)}`;

        // Calculate Wallet Debits
        let totalWalletDebits = 0;
        walletTransactions.forEach(wtx => {
            if (wtx.type === 'debit') {
                totalWalletDebits += wtx.amount;
            }
        });

        // Calculate VLE Gross Earnings (Commissions + direct store incomes, excluding other store operational expenses)
        let totalVleEarnings = 0;
        transactions.forEach(tx => {
            if (tx.type === 'income') {
                totalVleEarnings += tx.amount;
            } else if (tx.type === 'expense' && tx.category === 'CSC Wallet') {
                // Deduct only portal fees
                totalVleEarnings -= tx.amount;
            }
        });
        const dbIncome = document.getElementById('db-income-stat');
        if (dbIncome) dbIncome.textContent = `₹${totalVleEarnings.toFixed(2)}`;

        // Calculate Today's VLE Earnings
        const todayISO = getLocalISODate();
        let todayVleEarnings = 0;
        transactions.forEach(tx => {
            if (tx.isoDate === todayISO) {
                if (tx.type === 'income') {
                    todayVleEarnings += tx.amount;
                } else if (tx.type === 'expense' && tx.category === 'CSC Wallet') {
                    todayVleEarnings -= tx.amount;
                }
            }
        });
        const dbTodayEarnings = document.getElementById('db-today-earnings');
        if (dbTodayEarnings) dbTodayEarnings.textContent = `₹${todayVleEarnings.toFixed(2)}`;

        // Calculate Month's VLE Earnings (Monthly Income)
        const currentMonthISO = getLocalISODate().substring(0, 7);
        let monthVleEarnings = 0;
        transactions.forEach(tx => {
            if (tx.isoDate && tx.isoDate.substring(0, 7) === currentMonthISO) {
                if (tx.type === 'income') {
                    monthVleEarnings += tx.amount;
                } else if (tx.type === 'expense' && tx.category === 'CSC Wallet') {
                    monthVleEarnings -= tx.amount;
                }
            }
        });
        const dbMonthEarnings = document.getElementById('db-month-earnings');
        if (dbMonthEarnings) dbMonthEarnings.textContent = `₹${monthVleEarnings.toFixed(2)}`;

        // Calculate Shop Total Income (Wallet Debits)
        const dbShopIncome = document.getElementById('db-shop-income');
        if (dbShopIncome) dbShopIncome.textContent = `₹${totalWalletDebits.toFixed(2)}`;

        // Calculate Shop General Expenses (excluding portal wallet debits)
        let totalShopExpenses = 0;
        transactions.forEach(tx => {
            if (tx.type === 'expense' && tx.category !== 'CSC Wallet') {
                totalShopExpenses += tx.amount;
            }
        });
        const dbShopExpense = document.getElementById('db-shop-expense');
        if (dbShopExpense) dbShopExpense.textContent = `₹${totalShopExpenses.toFixed(2)}`;

        // Calculate Shop Net Balance (Total Income - Total Expense)
        const shopNetBalance = totalWalletDebits - totalShopExpenses;
        const dbShopBalance = document.getElementById('db-shop-balance');
        if (dbShopBalance) {
            dbShopBalance.textContent = `₹${shopNetBalance.toFixed(2)}`;
            if (shopNetBalance >= 0) {
                dbShopBalance.style.color = 'var(--success)';
                dbShopBalance.style.webkitTextFillColor = 'var(--success)';
            } else {
                dbShopBalance.style.color = 'var(--danger)';
                dbShopBalance.style.webkitTextFillColor = 'var(--danger)';
            }
        }
        
        if (balance >= 0) {
            balanceStat.style.color = 'var(--success)';
            balanceStat.style.webkitTextFillColor = 'var(--success)';
        } else {
            balanceStat.style.color = 'var(--danger)';
            balanceStat.style.webkitTextFillColor = 'var(--danger)';
        }

        // Load recent rows
        ledgerTableBody.innerHTML = '';
        if (filteredTxs.length === 0) {
            ledgerTableBody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 20px;">No transactions matched the filters.</td>
                </tr>
            `;
            return;
        }

        filteredTxs.forEach(tx => {
            const typeBadge = tx.type === 'income' 
                ? `<span class="badge badge-success">Income</span>` 
                : `<span class="badge badge-danger">Expense</span>`;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td style="padding: 10px 5px; color: var(--text-muted);">${tx.date}</td>
                <td style="padding: 10px 5px;">${typeBadge}</td>
                <td style="padding: 10px 5px; font-weight: 600;">${tx.category}</td>
                <td style="padding: 10px 5px; color: var(--text-muted);">${tx.mode}</td>
                <td style="padding: 10px 5px; text-align: right; font-weight: 700; color: ${tx.type === 'income' ? 'var(--success)' : 'var(--danger)'}">₹${tx.amount.toFixed(2)}</td>
                <td style="padding: 10px 5px; text-align: center;">
                    <button class="table-action-btn del-btn" data-id="${tx.id}">&times;</button>
                </td>
            `;

            row.querySelector('.del-btn').addEventListener('click', () => {
                // Automatically delete any linked wallet transaction
                walletTransactions = walletTransactions.filter(w => w.ledgerTxId !== tx.id);
                localStorage.setItem('csc_wallet_transactions', JSON.stringify(walletTransactions));
                
                transactions = transactions.filter(t => t.id !== tx.id);
                saveTransactions();
                loadWallet();
            });

            ledgerTableBody.appendChild(row);
        });
        updateQuickRecentLogs();
    }

    if (searchLedgerInput) searchLedgerInput.addEventListener('input', loadLedger);
    if (ledgerStartDateInput) ledgerStartDateInput.addEventListener('change', loadLedger);
    if (ledgerEndDateInput) ledgerEndDateInput.addEventListener('change', loadLedger);

    // 3b. CSC Wallet Management Handlers
    function addWalletTransaction(type, amount, desc, customIsoDate = null, ledgerTxId = null) {
        const isoDate = customIsoDate || getLocalISODate();
        let formattedDate;
        if (customIsoDate) {
            const parts = customIsoDate.split('-');
            const dObj = new Date(parts[0], parts[1] - 1, parts[2]);
            formattedDate = dObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
        } else {
            formattedDate = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
        }

        const newWtx = {
            id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
            date: formattedDate,
            isoDate: isoDate,
            type, // 'credit' or 'debit'
            amount: parseFloat(amount) || 0,
            desc: desc || '-',
            ledgerTxId
        };
        
        walletTransactions.unshift(newWtx);
        saveWalletTransactions();
    }

    function saveWalletTransactions() {
        localStorage.setItem('csc_wallet_transactions', JSON.stringify(walletTransactions));
        loadWallet();
    }

    function loadWallet() {
        // Reload wallet transactions from localStorage to sync updates
        walletTransactions = JSON.parse(localStorage.getItem('csc_wallet_transactions') || '[]');

        // Calculate running balance by playing transactions oldest to newest
        const sorted = [...walletTransactions].reverse();
        let running = 0;
        const runningBalances = {};
        sorted.forEach(wtx => {
            if (wtx.type === 'credit') {
                running += wtx.amount;
            } else {
                running -= wtx.amount;
            }
            runningBalances[wtx.id] = running;
        });

        const currentBalance = running;

        let totalWalletExpense = 0;
        walletTransactions.forEach(wtx => {
            if (wtx.type === 'debit') {
                totalWalletExpense += wtx.amount;
            }
        });

        const wBalanceStat = document.getElementById('wallet-balance-stat');
        const wExpenseStat = document.getElementById('wallet-expense-stat');
        const dbWalletBalance = document.getElementById('db-wallet-balance');
        if (wBalanceStat) wBalanceStat.textContent = `₹${currentBalance.toFixed(2)}`;
        if (wExpenseStat) wExpenseStat.textContent = `₹${totalWalletExpense.toFixed(2)}`;
        if (dbWalletBalance) dbWalletBalance.textContent = `₹${currentBalance.toFixed(2)}`;

        const walletTableBody = document.getElementById('wallet-table-body');
        if (!walletTableBody) return;

        const searchWalletInput = document.getElementById('search-wallet-input');
        const searchQuery = searchWalletInput ? searchWalletInput.value.toLowerCase().trim() : '';

        const filtered = walletTransactions.filter(wtx => {
            if (searchQuery) {
                return wtx.desc.toLowerCase().includes(searchQuery) || wtx.type.toLowerCase().includes(searchQuery);
            }
            return true;
        });

        walletTableBody.innerHTML = '';
        if (filtered.length === 0) {
            walletTableBody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 20px;">No wallet transactions match the filters.</td>
                </tr>
            `;
            return;
        }

        filtered.forEach(wtx => {
            const typeBadge = wtx.type === 'credit'
                ? `<span class="badge badge-success">Credit</span>`
                : `<span class="badge badge-danger">Debit</span>`;

            const balAtTx = runningBalances[wtx.id] || 0;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td style="padding: 10px 5px; color: var(--text-muted);">${wtx.date}</td>
                <td style="padding: 10px 5px;">${typeBadge}</td>
                <td style="padding: 10px 5px; font-weight: 500;">${wtx.desc}</td>
                <td style="padding: 10px 5px; text-align: right; font-weight: 700; color: ${wtx.type === 'credit' ? 'var(--success)' : 'var(--danger)'}">
                    ${wtx.type === 'credit' ? '+' : '-'}₹${wtx.amount.toFixed(2)}
                </td>
                <td style="padding: 10px 5px; text-align: right; font-weight: 600; color: var(--text-main)">₹${balAtTx.toFixed(2)}</td>
                <td style="padding: 10px 5px; text-align: center;">
                    <button class="table-action-btn del-wallet-btn" data-id="${wtx.id}">&times;</button>
                </td>
            `;

            row.querySelector('.del-wallet-btn').addEventListener('click', () => {
                if (confirm('Delete this wallet record? This will adjust the wallet balance.')) {
                    if (wtx.ledgerTxId) {
                        transactions = transactions.filter(t => t.id !== wtx.ledgerTxId);
                        saveTransactions();
                    }
                    walletTransactions = walletTransactions.filter(w => w.id !== wtx.id);
                    saveWalletTransactions();
                }
            });

            walletTableBody.appendChild(row);
        });

        // Update dashboard stats when wallet changes
        loadLedger();
    }

    const searchWalletInput = document.getElementById('search-wallet-input');
    if (searchWalletInput) searchWalletInput.addEventListener('input', loadWallet);


    // 4. Customer Directory & Dues Handlers
    const saveCustBtn = document.getElementById('save-cust-btn');
    const custNameInput = document.getElementById('cust-name');
    const custPhoneInput = document.getElementById('cust-phone');
    const addressInput = document.getElementById('cust-address');
    const serviceSelect = document.getElementById('cust-service-select');
    const serviceManualGroup = document.getElementById('cust-service-manual-group');
    const serviceManualInput = document.getElementById('cust-service-manual');
    const custChargeInput = document.getElementById('cust-charge');
    const custPaidInput = document.getElementById('cust-paid');
    const custWorkStatusInput = document.getElementById('cust-work-status');

    const commCalcLbl = document.getElementById('cust-comm-calc-lbl');
    const duesCalcLbl = document.getElementById('cust-dues-calc-lbl');
    
    const custTotalStat = document.getElementById('cust-total-stat');
    const custDuesStat = document.getElementById('cust-dues-stat');
    const customerTableBody = document.getElementById('customer-table-body');
    const searchCustomersInput = document.getElementById('search-customers-input');

    // Populate service dropdown dynamic rates
    function populateServiceDropdown() {
        if (!serviceSelect) return;
        const currentSel = serviceSelect.value;
        serviceSelect.innerHTML = '<option value="" disabled selected>-- Select Service Availed --</option>';
        serviceRates.forEach(rate => {
            const opt = document.createElement('option');
            opt.value = rate.id;
            opt.textContent = `${rate.name} (Fee: ₹${rate.customerFee})`;
            serviceSelect.appendChild(opt);
        });
        const customOpt = document.createElement('option');
        customOpt.value = 'custom';
        customOpt.textContent = 'Other / Custom Service';
        serviceSelect.appendChild(customOpt);

        if (currentSel) {
            serviceSelect.value = currentSel;
        }
    }

    // Dropdown change listener
    if (serviceSelect) {
        serviceSelect.addEventListener('change', () => {
            const val = serviceSelect.value;
            if (val === 'custom') {
                serviceManualGroup.style.display = 'block';
                custChargeInput.value = '';
                custPaidInput.value = '';
                updateCalculatedIndicators(0, 0, 0);
            } else {
                serviceManualGroup.style.display = 'none';
                const service = serviceRates.find(r => r.id === val);
                if (service) {
                    custChargeInput.value = service.customerFee;
                    custPaidInput.value = service.customerFee; // Defaults to fully paid
                    updateCalculatedIndicators(service.customerFee, service.customerFee, service.netMargin);
                }
            }
        });
    }

    function recalculateCustomerForm() {
        const charge = parseFloat(custChargeInput.value) || 0;
        const paid = parseFloat(custPaidInput.value) || 0;

        let commission = 0;
        const val = serviceSelect.value;
        if (val && val !== 'custom') {
            const service = serviceRates.find(r => r.id === val);
            if (service) {
                // Commission earned = Paid Amount - Govt Portal Fee (loss is bounded at 0)
                commission = Math.max(0, paid - service.govtFee);
            }
        } else {
            // For custom services, Govt portal fee is 0, so commission is the full paid amount
            commission = paid;
        }

        updateCalculatedIndicators(charge, paid, commission);
    }

    function updateCalculatedIndicators(charge, paid, commission) {
        const dues = Math.max(0, charge - paid);
        if (duesCalcLbl) duesCalcLbl.textContent = `₹${dues.toFixed(2)}`;
        if (commCalcLbl) commCalcLbl.textContent = `₹${commission.toFixed(2)}`;
    }

    if (custChargeInput) custChargeInput.addEventListener('input', recalculateCustomerForm);
    if (custPaidInput) custPaidInput.addEventListener('input', recalculateCustomerForm);

    function saveCustomers() {
        localStorage.setItem('csc_csp_customers', JSON.stringify(customers));
        loadCustomers();
    }

    if (saveCustBtn) {
        saveCustBtn.addEventListener('click', () => {
            const name = custNameInput.value.trim();
            const phone = custPhoneInput.value.trim();
            const address = addressInput.value.trim();
            const serviceVal = serviceSelect.value;
            const charge = parseFloat(custChargeInput.value) || 0;
            const paid = parseFloat(custPaidInput.value) || 0;
            const customCustDate = custDateInput ? custDateInput.value : '';

            if (!name) {
                alert('Please enter a Customer Name.');
                return;
            }

            if (!serviceVal) {
                alert('Please select a service.');
                return;
            }

            let serviceName = '';
            let govtFee = 0;
            let netMargin = 0;

            if (serviceVal === 'custom') {
                serviceName = serviceManualInput.value.trim() || 'Custom Service';
                govtFee = 0;
                netMargin = charge;
            } else {
                const service = serviceRates.find(r => r.id === serviceVal);
                if (service) {
                    serviceName = service.name;
                    govtFee = service.govtFee;
                    netMargin = service.netMargin;
                }
            }

            const dues = Math.max(0, charge - paid);
            const status = dues <= 0 ? 'Paid' : 'Pending';

            const custIsoDate = customCustDate || getLocalISODate();
            let custFormattedDate;
            if (customCustDate) {
                const parts = customCustDate.split('-');
                const dObj = new Date(parts[0], parts[1] - 1, parts[2]);
                custFormattedDate = dObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
            } else {
                custFormattedDate = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
            }

            // Generate next customer number
            let custNo = 1001;
            if (customers.length > 0) {
                const nos = customers.map(c => c.custNo).filter(n => typeof n === 'number');
                if (nos.length > 0) {
                    custNo = Math.max(...nos) + 1;
                } else {
                    custNo = 1001 + customers.length;
                }
            }

            const workStatus = custWorkStatusInput ? custWorkStatusInput.value : 'Complete';
            const newCust = {
                id: Date.now().toString(),
                custNo,
                date: custFormattedDate,
                isoDate: custIsoDate,
                name,
                phone: phone || '-',
                address: address || '-',
                service: serviceName,
                charge,
                paid,
                dues,
                status,
                govtFee,
                workStatus
            };

            customers.unshift(newCust);

            // Log double entry cash-flow transactions in ledger
            if (paid > 0) {
                // Log Cash/UPI Received (Income)
                addTransactionDirectly('income', 'Service Charge', paid, 'Cash', `Cash from customer: ${name} (${serviceName})`, custIsoDate);
            }

            if (govtFee > 0) {
                const linkId = Date.now().toString() + Math.random().toString(36).substr(2, 5);
                // Log Portal Wallet Deduction (Expense)
                addTransactionDirectly('expense', 'CSC Wallet', govtFee, 'CSC Wallet', `Govt Portal Fee debited: ${name} (${serviceName})`, custIsoDate);
                
                // Link it
                if (transactions.length > 0) {
                    transactions[0].id = linkId;
                    saveTransactions();
                }

                // Log wallet debit
                addWalletTransaction('debit', govtFee, `Govt Portal Fee: ${name} (${serviceName})`, custIsoDate, linkId);
            }

            saveCustomers();

            // Clear inputs
            custNameInput.value = '';
            custPhoneInput.value = '';
            addressInput.value = '';
            serviceSelect.value = '';
            serviceManualInput.value = '';
            serviceManualGroup.style.display = 'none';
            custChargeInput.value = '';
            custPaidInput.value = '';
            if (custWorkStatusInput) custWorkStatusInput.value = 'Complete';
            if (custDateInput) custDateInput.value = getLocalISODate();
            updateCalculatedIndicators(0, 0, 0);

            if (window.incrementProcessedCount) window.incrementProcessedCount();

            // Prompt for receipt printing
            setTimeout(() => {
                if (confirm(`Do you want to print a receipt for Customer: ${newCust.name}?`)) {
                    printServiceReceipt(newCust);
                }
                setTimeout(() => {
                    if (confirm(`Do you want to send the receipt to Customer: ${newCust.name} via WhatsApp?`)) {
                        sendWhatsAppReceipt(newCust);
                    }
                }, 100);
            }, 100);
        });
    }

    function printServiceReceipt(cust) {
        const printableArea = document.getElementById('printable-area');
        if (!printableArea) return;

        const shopName = localStorage.getItem('csc_profile_shop_name') || 'APNA DIGITAL CSC CENTER';
        const mobile = localStorage.getItem('csc_profile_phone') || '+91 98765 43210';
        const address = localStorage.getItem('csc_profile_address') || 'Main Market, India';

        const statusLabel = cust.status === 'Paid' ? 'SUCCESSFUL / PAID' : 'PENDING DUES';

        printableArea.innerHTML = `
            <div class="service-print-slip recharge-print-slip">
                <h2>${shopName.toUpperCase()}</h2>
                <div style="font-size: 10px; text-align: center; color: #444; margin-bottom: 2px;">Address: ${address}</div>
                <div style="font-size: 10px; text-align: center; color: #444; margin-bottom: 8px;">Helpdesk: ${mobile}</div>
                
                <div class="slip-divider"></div>
                <h3 style="text-align: center; font-size: 13px; font-weight: bold; margin: 5px 0;">TRANSACTION RECEIPT</h3>
                <div class="slip-divider"></div>

                <div class="slip-row">
                    <span>Receipt No:</span>
                    <span style="font-weight: bold;">#${cust.custNo || 'N/A'}</span>
                </div>
                <div class="slip-row">
                    <span>Date:</span>
                    <span>${cust.date}</span>
                </div>
                <div class="slip-row">
                    <span>Customer Name:</span>
                    <span style="font-weight: 600;">${cust.name}</span>
                </div>
                <div class="slip-row">
                    <span>Mobile No:</span>
                    <span>${cust.phone || '-'}</span>
                </div>
                <div class="slip-row">
                    <span>Address:</span>
                    <span>${cust.address || '-'}</span>
                </div>
                <div class="slip-row">
                    <span>Service:</span>
                    <span style="font-weight: 600;">${cust.service}</span>
                </div>
                <div class="slip-row">
                    <span>Govt Portal Fee:</span>
                    <span>₹${(cust.govtFee || 0).toFixed(2)}</span>
                </div>
                <div class="slip-row">
                    <span>Status:</span>
                    <span style="font-weight: bold; color: ${cust.status === 'Paid' ? '#000' : '#d97706'};">${statusLabel}</span>
                </div>

                <div class="slip-divider"></div>
                <div class="slip-row">
                    <span>Service Charge:</span>
                    <span>₹${cust.charge.toFixed(2)}</span>
                </div>
                <div class="slip-row">
                    <span>Paid Amount:</span>
                    <span style="font-weight: bold;">₹${cust.paid.toFixed(2)}</span>
                </div>
                <div class="slip-row total">
                    <span>PENDING DUES:</span>
                    <span style="color: ${cust.dues > 0 ? '#b91c1c' : '#000'};">₹${cust.dues.toFixed(2)}</span>
                </div>
                <div class="slip-divider"></div>

                <div style="text-align: center; font-size: 10px; margin-top: 15px; font-style: italic;">
                    Thank you for choosing our digital services!<br>Please visit again.
                </div>
            </div>
        `;

        window.print();
    }

    function sendWhatsAppReceipt(cust) {
        const shopName = localStorage.getItem('csc_profile_shop_name') || 'APNA DIGITAL CSC CENTER';
        const mobile = localStorage.getItem('csc_profile_phone') || '+91 98765 43210';
        const address = localStorage.getItem('csc_profile_address') || 'Main Market, India';

        const statusLabel = cust.status === 'Paid' ? 'SUCCESSFUL / PAID' : 'PENDING DUES';
        
        let message = `*${shopName.toUpperCase()}*\n`;
        message += `Address: ${address}\n`;
        message += `Helpdesk: ${mobile}\n\n`;
        
        message += `*TRANSACTION RECEIPT*\n`;
        message += `--------------------------------\n`;
        message += `Receipt No: #${cust.custNo || 'N/A'}\n`;
        message += `Date: ${cust.date}\n`;
        message += `Customer: ${cust.name}\n`;
        message += `Mobile: ${cust.phone || '-'}\n`;
        if (cust.address && cust.address !== '-') {
            message += `Address: ${cust.address}\n`;
        }
        message += `Service: ${cust.service}\n`;
        message += `Status: ${statusLabel}\n`;
        message += `--------------------------------\n`;
        message += `Service Charge: Rs. ${cust.charge.toFixed(2)}\n`;
        message += `Paid Amount: Rs. ${cust.paid.toFixed(2)}\n`;
        message += `*Pending Dues: Rs. ${cust.dues.toFixed(2)}*\n`;
        message += `--------------------------------\n`;
        message += `Thank you for choosing our digital services! Please visit again.`;

        let phoneNo = (cust.phone || '').trim().replace(/[^0-9]/g, '');
        if (!phoneNo || phoneNo.length < 10) {
            const inputNo = prompt('Please enter the customer\'s 10-digit WhatsApp number:', '');
            if (!inputNo) return;
            phoneNo = inputNo.trim().replace(/[^0-9]/g, '');
        }
        if (phoneNo.length === 10) {
            phoneNo = '91' + phoneNo;
        }

        const encodedText = encodeURIComponent(message);
        const waUrl = `https://wa.me/${phoneNo}?text=${encodedText}`;
        window.open(waUrl, '_blank');
    }

    function loadCustomers() {
        const query = searchCustomersInput ? searchCustomersInput.value.toLowerCase().trim() : '';
        const startDate = custStartDateInput ? custStartDateInput.value : '';
        const endDate = custEndDateInput ? custEndDateInput.value : '';

        let filteredCustomers = customers.filter(c => {
            if (query) {
                const name = c.name.toLowerCase();
                const phone = c.phone;
                const address = (c.address || '').toLowerCase();
                const service = c.service.toLowerCase();
                const cNoStr = c.custNo ? c.custNo.toString() : '';

                if (!name.includes(query) && !phone.includes(query) && !address.includes(query) && !service.includes(query) && !cNoStr.includes(query)) {
                    return false;
                }
            }

            const custIso = c.isoDate || getLocalISODate();
            if (startDate && custIso < startDate) return false;
            if (endDate && custIso > endDate) return false;

            return true;
        });

        let totalDues = 0;
        filteredCustomers.forEach(c => {
            totalDues += c.dues;
        });

        // Update filtered card summary
        custTotalStat.textContent = filteredCustomers.length;
        custDuesStat.textContent = `₹${totalDues.toFixed(2)}`;

        // Calculate All-time stats for Dashboard
        let allTimeDues = 0;
        customers.forEach(c => {
            allTimeDues += c.dues;
        });
        const dbDues = document.getElementById('db-dues-stat');
        if (dbDues) dbDues.textContent = `₹${allTimeDues.toFixed(2)}`;

        customerTableBody.innerHTML = '';
        if (filteredCustomers.length === 0) {
            customerTableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 20px;">No customers matched the filters.</td>
                </tr>
            `;
            return;
        }

        filteredCustomers.forEach(cust => {
            const statusBadge = cust.status === 'Paid'
                ? `<span class="badge badge-success">Paid</span>`
                : `<span class="badge badge-warning">Dues</span>`;

            const workStatus = cust.workStatus || 'Complete';
            const workStatusSelect = `
                <select class="work-status-select" data-id="${cust.id}" style="padding: 2px 4px; font-size: 10px; font-weight: 700; border-radius: var(--radius-sm); border: none; outline: none; cursor: pointer; text-transform: uppercase; text-align: center; width: 85px; background-color: ${workStatus === 'Complete' ? 'rgba(16, 185, 129, 0.15)' : (workStatus === 'Processing' ? 'rgba(99, 102, 241, 0.15)' : 'rgba(239, 68, 68, 0.15)')}; color: ${workStatus === 'Complete' ? 'var(--success)' : (workStatus === 'Processing' ? 'var(--primary)' : 'var(--danger)')};">
                    <option value="Pending" ${workStatus === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="Processing" ${workStatus === 'Processing' ? 'selected' : ''}>Processing</option>
                    <option value="Complete" ${workStatus === 'Complete' ? 'selected' : ''}>Complete</option>
                </select>
            `;

            const actionButtons = cust.status === 'Pending'
                ? `<button class="table-action-btn pay-btn" data-id="${cust.id}">Clear Dues</button>
                   <button class="table-action-btn print-slip-btn" data-id="${cust.id}">Slip</button>
                   <button class="table-action-btn wa-btn" data-id="${cust.id}" style="background: rgba(34, 197, 94, 0.1); color: #22c55e;">WA</button>
                   <button class="table-action-btn del-btn" data-id="${cust.id}">&times;</button>`
                : `<button class="table-action-btn print-slip-btn" data-id="${cust.id}">Slip</button>
                   <button class="table-action-btn wa-btn" data-id="${cust.id}" style="background: rgba(34, 197, 94, 0.1); color: #22c55e;">WA</button>
                   <button class="table-action-btn del-btn" data-id="${cust.id}">&times;</button>`;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td style="padding: 10px 5px;">
                    <span style="font-size: 11px; font-weight: bold; color: var(--primary); background: rgba(99, 102, 241, 0.08); padding: 2px 6px; border-radius: 4px; font-family: monospace; margin-right: 4px;">#${cust.custNo || 'N/A'}</span>
                    <strong>${cust.name}</strong>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
                        Mob: ${cust.phone} | Addr: ${cust.address} | ${cust.date}
                    </div>
                </td>
                <td style="padding: 10px 5px;">${cust.service}</td>
                <td style="padding: 10px 5px; text-align: right; font-weight: 500;">₹${cust.charge.toFixed(2)}</td>
                <td style="padding: 10px 5px; text-align: right; color: var(--success);">₹${cust.paid.toFixed(2)}</td>
                <td style="padding: 10px 5px; text-align: right; font-weight: 700; color: ${cust.dues > 0 ? 'var(--warning)' : 'var(--text-main)'}">₹${cust.dues.toFixed(2)}</td>
                <td style="padding: 10px 5px; text-align: center;">
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                        ${statusBadge}
                        ${workStatusSelect}
                    </div>
                </td>
                <td style="padding: 10px 5px; text-align: center;">
                    <div class="table-cell-actions">${actionButtons}</div>
                </td>
            `;

            // Change event for Work Status Select dropdown
            const workSelect = row.querySelector('.work-status-select');
            if (workSelect) {
                workSelect.addEventListener('change', (e) => {
                    const newWorkStatus = e.target.value;
                    cust.workStatus = newWorkStatus;
                    saveCustomers();

                    // Dynamically update background and text colors of the select dropdown
                    if (newWorkStatus === 'Complete') {
                        workSelect.style.backgroundColor = 'rgba(16, 185, 129, 0.15)';
                        workSelect.style.color = 'var(--success)';
                    } else if (newWorkStatus === 'Processing') {
                        workSelect.style.backgroundColor = 'rgba(99, 102, 241, 0.15)';
                        workSelect.style.color = 'var(--primary)';
                    } else {
                        workSelect.style.backgroundColor = 'rgba(239, 68, 68, 0.15)';
                        workSelect.style.color = 'var(--danger)';
                    }
                });
            }

            // Clear Dues click
            const payBtn = row.querySelector('.pay-btn');
            if (payBtn) {
                payBtn.addEventListener('click', () => {
                    const duesAmt = cust.dues;
                    
                    // Settle Dues
                    cust.paid = cust.charge;
                    cust.dues = 0;
                    cust.status = 'Paid';

                    // Automatically log Income in Transaction ledger (using customer's custom date)
                    addTransactionDirectly('income', 'Service Charge', duesAmt, 'Cash', `Cleared pending dues: ${cust.name} (${cust.service})`, cust.isoDate);

                    saveCustomers();

                    // Prompt for updated receipt & WhatsApp share
                    setTimeout(() => {
                        if (confirm(`Dues of ₹${duesAmt} cleared successfully for ${cust.name}!\n\nDo you want to print an updated receipt?`)) {
                            printServiceReceipt(cust);
                        }
                        setTimeout(() => {
                            if (confirm(`Do you want to send the updated receipt via WhatsApp?`)) {
                                sendWhatsAppReceipt(cust);
                            }
                        }, 100);
                    }, 100);
                });
            }

            // Print Slip click
            const printBtn = row.querySelector('.print-slip-btn');
            if (printBtn) {
                printBtn.addEventListener('click', () => {
                    printServiceReceipt(cust);
                });
            }

            // WhatsApp click
            const waBtn = row.querySelector('.wa-btn');
            if (waBtn) {
                waBtn.addEventListener('click', () => {
                    sendWhatsAppReceipt(cust);
                });
            }

            row.querySelector('.del-btn').addEventListener('click', () => {
                customers = customers.filter(c => c.id !== cust.id);
                saveCustomers();
            });

            customerTableBody.appendChild(row);
        });
        updateQuickRecentLogs();
        renderQuickSearch();
    }

    if (searchCustomersInput) {
        searchCustomersInput.addEventListener('input', loadCustomers);
    }
    if (custStartDateInput) custStartDateInput.addEventListener('change', loadCustomers);
    if (custEndDateInput) custEndDateInput.addEventListener('change', loadCustomers);


    // 5. Service Rates Management (Grid-Card & Modal CRUD UI)
    const servicesCardsGrid = document.getElementById('services-cards-grid');
    const servicesResetBtn = document.getElementById('services-reset-btn');
    const addServiceBtn = document.getElementById('add-service-btn');
    const searchServicesInput = document.getElementById('search-services-input');
    const categoryPills = document.querySelectorAll('#services-category-pills .category-pill');

    const cspServicesCardsGrid = document.getElementById('csp-services-cards-grid');
    const cspAddServiceBtn = document.getElementById('csp-add-service-btn');
    const cspSearchServicesInput = document.getElementById('csp-search-services-input');
    const cspCategoryPills = document.querySelectorAll('#csp-category-pills .category-pill');
    const cspServicesResetBtn = document.getElementById('csp-services-reset-btn');

    const modalOverlay = document.getElementById('service-modal-overlay');
    const modalForm = document.getElementById('service-modal-form');
    const modalTitle = document.getElementById('service-modal-title');
    const modalClose = document.getElementById('service-modal-close');
    const modalCancel = document.getElementById('service-modal-cancel');
    
    const modalServiceName = document.getElementById('modal-service-name');
    const modalServiceCategory = document.getElementById('modal-service-category');
    const modalGovtFee = document.getElementById('modal-govt-fee');
    const modalCustFee = document.getElementById('modal-cust-fee');
    const modalCommissionLbl = document.getElementById('modal-commission-lbl');
    const serviceEditId = document.getElementById('service-edit-id');

    let activeCategoryFilter = 'all';
    let activeSearchFilter = '';

    function saveRates() {
        localStorage.setItem('csc_csp_rates', JSON.stringify(serviceRates));
        loadRates();
        populateServiceDropdown();
        populateDashboardServiceDropdown();
    }

    function loadRates() {
        const grids = [];
        if (servicesCardsGrid) grids.push(servicesCardsGrid);
        if (cspServicesCardsGrid) grids.push(cspServicesCardsGrid);

        if (grids.length === 0) return;
        grids.forEach(g => g.innerHTML = '');

        const filtered = serviceRates.filter(rate => {
            // Category filter
            if (activeCategoryFilter !== 'all' && rate.category !== activeCategoryFilter) {
                return false;
            }
            // Search query filter
            if (activeSearchFilter) {
                const name = rate.name.toLowerCase();
                const category = rate.category.toLowerCase();
                if (!name.includes(activeSearchFilter) && !category.includes(activeSearchFilter)) {
                    return false;
                }
            }
            return true;
        });

        if (filtered.length === 0) {
            grids.forEach(g => {
                g.innerHTML = `
                    <div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 40px 0;">
                        <i data-lucide="info" style="width: 48px; height: 48px; margin-bottom: 12px; opacity: 0.5; display: inline-block;"></i>
                        <p style="font-size: 14px;">No services match the criteria. Click "+ Add Service" to create one.</p>
                    </div>
                `;
            });
            if (window.lucide) window.lucide.createIcons();
            return;
        }

        filtered.forEach(rate => {
            grids.forEach(grid => {
                const card = document.createElement('div');
                card.className = 'service-item-card';
                card.innerHTML = `
                    <div class="service-item-card-header">
                        <div>
                            <h4 class="service-item-name">${rate.name}</h4>
                            <span class="service-item-category">${rate.category}</span>
                        </div>
                        <div class="service-card-action-btns">
                            <button class="service-action-icon-btn edit-service-btn" title="Edit Service">
                                <i data-lucide="edit-3"></i>
                            </button>
                            <button class="service-action-icon-btn del-service-btn" title="Delete Service">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </div>
                    <div class="service-item-comm">₹${rate.netMargin.toFixed(0)}</div>
                `;

                // Edit Handler
                card.querySelector('.edit-service-btn').addEventListener('click', (e) => {
                    e.stopPropagation();
                    openModal(rate);
                });

                // Delete Handler
                card.querySelector('.del-service-btn').addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (confirm(`Are you sure you want to delete "${rate.name}"?`)) {
                        serviceRates = serviceRates.filter(r => r.id !== rate.id);
                        saveRates();
                    }
                });

                grid.appendChild(card);
            });
        });

        if (window.lucide) window.lucide.createIcons();
    }

    function openModal(service = null) {
        if (!modalOverlay) return;
        
        modalForm.reset();
        
        if (service) {
            modalTitle.textContent = 'Edit Service';
            serviceEditId.value = service.id;
            modalServiceName.value = service.name;
            modalServiceCategory.value = service.category;
            modalGovtFee.value = service.govtFee;
            modalCustFee.value = service.customerFee;
            updateModalCommission();
        } else {
            modalTitle.textContent = 'Add New Service';
            serviceEditId.value = '';
            modalGovtFee.value = 0;
            modalCustFee.value = 0;
            modalCommissionLbl.textContent = '₹0.00';
        }
        
        modalOverlay.classList.add('active');
    }

    function closeModal() {
        if (modalOverlay) modalOverlay.classList.remove('active');
    }

    function updateModalCommission() {
        const govt = parseFloat(modalGovtFee.value) || 0;
        const cust = parseFloat(modalCustFee.value) || 0;
        const comm = cust - govt;
        modalCommissionLbl.textContent = `₹${comm.toFixed(2)}`;
    }

    if (modalGovtFee) modalGovtFee.addEventListener('input', updateModalCommission);
    if (modalCustFee) modalCustFee.addEventListener('input', updateModalCommission);
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalCancel) modalCancel.addEventListener('click', closeModal);

    if (addServiceBtn) addServiceBtn.addEventListener('click', () => openModal(null));

    if (modalForm) {
        modalForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const id = serviceEditId.value;
            const name = modalServiceName.value.trim();
            const category = modalServiceCategory.value;
            const govtFee = parseFloat(modalGovtFee.value) || 0;
            const customerFee = parseFloat(modalCustFee.value) || 0;
            const netMargin = customerFee - govtFee;

            if (id) {
                // Edit Mode
                const index = serviceRates.findIndex(r => r.id === id);
                if (index !== -1) {
                    serviceRates[index] = { id, name, category, govtFee, customerFee, netMargin };
                }
            } else {
                // Add Mode
                const newService = {
                    id: Date.now().toString(),
                    name,
                    category,
                    govtFee,
                    customerFee,
                    netMargin
                };
                serviceRates.push(newService);
            }

            saveRates();
            closeModal();
        });
    }

    if (cspAddServiceBtn) cspAddServiceBtn.addEventListener('click', () => openModal(null));

    if (categoryPills) {
        categoryPills.forEach(pill => {
            pill.addEventListener('click', () => {
                categoryPills.forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                activeCategoryFilter = pill.getAttribute('data-category');
                
                // Sync with csp pills
                if (cspCategoryPills) {
                    cspCategoryPills.forEach(p => {
                        if (p.getAttribute('data-category') === activeCategoryFilter) {
                            p.classList.add('active');
                        } else {
                            p.classList.remove('active');
                        }
                    });
                }
                
                loadRates();
            });
        });
    }

    if (cspCategoryPills) {
        cspCategoryPills.forEach(pill => {
            pill.addEventListener('click', () => {
                cspCategoryPills.forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                activeCategoryFilter = pill.getAttribute('data-category');
                
                // Sync with main pills
                if (categoryPills) {
                    categoryPills.forEach(p => {
                        if (p.getAttribute('data-category') === activeCategoryFilter) {
                            p.classList.add('active');
                        } else {
                            p.classList.remove('active');
                        }
                    });
                }
                
                loadRates();
            });
        });
    }

    if (searchServicesInput) {
        searchServicesInput.addEventListener('input', (e) => {
            activeSearchFilter = e.target.value.toLowerCase().trim();
            if (cspSearchServicesInput) cspSearchServicesInput.value = e.target.value;
            loadRates();
        });
    }

    if (cspSearchServicesInput) {
        cspSearchServicesInput.addEventListener('input', (e) => {
            activeSearchFilter = e.target.value.toLowerCase().trim();
            if (searchServicesInput) searchServicesInput.value = e.target.value;
            loadRates();
        });
    }

    if (servicesResetBtn) {
        servicesResetBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to reset all service rates to standard defaults?')) {
                serviceRates = [...defaultRates];
                saveRates();
            }
        });
    }

    if (cspServicesResetBtn) {
        cspServicesResetBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to reset all service rates to standard defaults?')) {
                serviceRates = [...defaultRates];
                saveRates();
            }
        });
    }


    // 5b. Dashboard Quick Entry Panel Logic
    const qSaveTxBtn = document.getElementById('q-save-tx-btn');
    const qTxType = document.getElementById('q-tx-type');
    const qTxAmount = document.getElementById('q-tx-amount');
    const qTxCategory = document.getElementById('q-tx-category');
    const qTxMode = document.getElementById('q-tx-mode');
    const qTxDesc = document.getElementById('q-tx-desc');

    const qSaveCustBtn = document.getElementById('q-save-cust-btn');
    const qCustName = document.getElementById('q-cust-name');
    const qCustPhone = document.getElementById('q-cust-phone');
    const qCustAddress = document.getElementById('q-cust-address');
    const qCustServiceSelect = document.getElementById('q-cust-service-select');
    const qCustServiceManualGroup = document.getElementById('q-cust-service-manual-group');
    const qCustServiceManual = document.getElementById('q-cust-service-manual');
    const qCustCharge = document.getElementById('q-cust-charge');
    const qCustPaid = document.getElementById('q-cust-paid');
    const qCustCommLbl = document.getElementById('q-cust-comm-lbl');
    const qCustDuesLbl = document.getElementById('q-cust-dues-lbl');
    const qCustWorkStatus = document.getElementById('q-cust-work-status');

    // Dashboard Quick Tabs Switching
    const qBtnTx = document.getElementById('q-btn-tx-tab');
    const qBtnCust = document.getElementById('q-btn-cust-tab');
    const qBtnSearch = document.getElementById('q-btn-search-tab');
    const qPanelTx = document.getElementById('q-panel-tx');
    const qPanelCust = document.getElementById('q-panel-cust');
    const qPanelSearch = document.getElementById('q-panel-search');

    if (qBtnTx && qBtnCust && qBtnSearch) {
        const qTabs = [qBtnTx, qBtnCust, qBtnSearch];

        function resetQuickTabs() {
            qTabs.forEach(btn => btn.classList.remove('active'));
            [qPanelTx, qPanelCust, qPanelSearch].forEach(panel => {
                if (panel) panel.style.display = 'none';
            });
        }

        qBtnTx.addEventListener('click', () => {
            resetQuickTabs();
            qBtnTx.classList.add('active');
            qPanelTx.style.display = 'flex';
        });

        qBtnCust.addEventListener('click', () => {
            resetQuickTabs();
            qBtnCust.classList.add('active');
            qPanelCust.style.display = 'flex';
        });

        qBtnSearch.addEventListener('click', () => {
            resetQuickTabs();
            qBtnSearch.classList.add('active');
            qPanelSearch.style.display = 'flex';
            renderQuickSearch();
        });
    }

    // Dashboard Quick Dues Search Implementation
    const qSearchCustInput = document.getElementById('q-search-cust-input');
    const qSearchResults = document.getElementById('q-search-results');

    if (qSearchCustInput) {
        qSearchCustInput.addEventListener('input', () => {
            renderQuickSearch();
        });
    }

    function renderQuickSearch() {
        if (!qSearchResults) return;
        qSearchResults.innerHTML = '';

        const query = qSearchCustInput ? qSearchCustInput.value.toLowerCase().trim() : '';

        // Filter: if search query is empty, show all customers who have pending dues.
        // If query is not empty, match by name or phone/mobile number.
        const filtered = customers.filter(c => {
            if (query) {
                const name = c.name.toLowerCase();
                const phone = c.phone || '';
                const cNoStr = c.custNo ? c.custNo.toString() : '';
                return name.includes(query) || phone.includes(query) || cNoStr.includes(query);
            } else {
                // Default: show only customers with pending dues when query is empty
                return c.dues > 0;
            }
        });

        if (filtered.length === 0) {
            qSearchResults.innerHTML = `<span style="font-size: 12px; color: var(--text-muted); text-align: center; padding: 12px; display: block;">${query ? 'No matching customer found.' : 'No customers with pending dues.'}</span>`;
            return;
        }

        filtered.slice(0, 10).forEach(c => {
            const row = document.createElement('div');
            row.style.display = 'flex';
            row.style.justifyContent = 'space-between';
            row.style.alignItems = 'center';
            row.style.padding = '8px 10px';
            row.style.background = 'var(--bg-primary)';
            row.style.borderRadius = '6px';
            row.style.borderLeft = `3px solid ${c.dues > 0 ? 'var(--warning)' : 'var(--success)'}`;
            row.style.fontSize = '12px';
            row.style.marginTop = '4px';

            const statusSection = c.dues > 0 
                ? `<button class="table-action-btn pay-btn q-clear-due-btn" data-id="${c.id}" style="padding: 4px 8px; font-size: 11px;">Clear Dues (₹${c.dues.toFixed(0)})</button>`
                : `<span class="badge badge-success" style="padding: 2px 6px; font-size: 10px;">Paid</span>`;

            row.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 2px; max-width: 65%;">
                    <span style="font-weight: 700; color: var(--text-main);">
                        <span style="font-size: 10px; font-weight: bold; color: var(--primary); background: rgba(99, 102, 241, 0.08); padding: 1px 4px; border-radius: 3px; font-family: monospace; margin-right: 3px;">#${c.custNo || 'N/A'}</span>
                        ${c.name}
                    </span>
                    <span style="font-size: 10px; color: var(--text-muted);">Mob: ${c.phone} | ${c.service}</span>
                </div>
                <div>
                    ${statusSection}
                </div>
            `;

            const clearBtn = row.querySelector('.q-clear-due-btn');
            if (clearBtn) {
                clearBtn.addEventListener('click', () => {
                    const duesAmt = c.dues;

                    // Settle Dues
                    c.paid = c.charge;
                    c.dues = 0;
                    c.status = 'Paid';

                    // Automatically log Income in Transaction ledger
                    addTransactionDirectly('income', 'Service Charge', duesAmt, 'Cash', `Cleared pending dues (Quick): ${c.name} (${c.service})`, c.isoDate);

                    saveCustomers();
                    
                    // Refresh search panel
                    renderQuickSearch();
                    
                    setTimeout(() => {
                        if (confirm(`Dues of ₹${duesAmt} cleared successfully for ${c.name}!\n\nDo you want to print an updated receipt?`)) {
                            printServiceReceipt(c);
                        }
                        setTimeout(() => {
                            if (confirm(`Do you want to send the updated receipt via WhatsApp?`)) {
                                sendWhatsAppReceipt(c);
                            }
                        }, 100);
                    }, 100);
                });
            }

            qSearchResults.appendChild(row);
        });
    }

    // Dashboard Quick Recent Logs Rendering
    function updateQuickRecentLogs() {
        const container = document.getElementById('q-recent-logs-container');
        if (!container) return;

        container.innerHTML = '';

        const recentTxs = transactions.slice(0, 3);
        const recentCusts = customers.slice(0, 2);

        if (recentTxs.length === 0 && recentCusts.length === 0) {
            container.innerHTML = `<span style="font-size: 12px; color: var(--text-muted); text-align: center; padding: 20px; display: block;">No recent logs.</span>`;
            return;
        }

        // Render transactions
        recentTxs.forEach(tx => {
            const div = document.createElement('div');
            div.style.display = 'flex';
            div.style.justifyContent = 'space-between';
            div.style.alignItems = 'center';
            div.style.padding = '8px 10px';
            div.style.background = 'var(--bg-primary)';
            div.style.borderRadius = '6px';
            div.style.borderLeft = `3px solid ${tx.type === 'income' ? 'var(--success)' : 'var(--danger)'}`;
            div.style.fontSize = '12px';

            div.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 2px; max-width: 70%;">
                    <span style="font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${tx.category}</span>
                    <span style="font-size: 10px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${tx.desc}</span>
                </div>
                <span style="font-weight: 700; color: ${tx.type === 'income' ? 'var(--success)' : 'var(--danger)'}">₹${tx.amount.toFixed(2)}</span>
            `;
            container.appendChild(div);
        });

        // Render customers
        recentCusts.forEach(c => {
            const div = document.createElement('div');
            div.style.display = 'flex';
            div.style.justifyContent = 'space-between';
            div.style.alignItems = 'center';
            div.style.padding = '8px 10px';
            div.style.background = 'var(--bg-primary)';
            div.style.borderRadius = '6px';
            div.style.borderLeft = `3px solid var(--primary)`;
            div.style.fontSize = '12px';
            div.style.marginTop = '4px';

            div.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 2px; max-width: 70%;">
                    <span style="font-weight: 600; color: var(--text-main); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">👤 ${c.name}</span>
                    <span style="font-size: 10px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Service: ${c.service}</span>
                </div>
                <div style="text-align: right; display: flex; flex-direction: column;">
                    <span style="font-weight: 700; color: var(--success)">Paid: ₹${c.paid.toFixed(2)}</span>
                    ${c.dues > 0 ? `<span style="font-size: 9px; font-weight: bold; color: var(--warning)">Dues: ₹${c.dues.toFixed(2)}</span>` : ''}
                </div>
            `;
            container.appendChild(div);
        });

        if (window.lucide) window.lucide.createIcons();
    }

    function populateDashboardServiceDropdown() {
        if (!qCustServiceSelect) return;
        const currentSel = qCustServiceSelect.value;
        qCustServiceSelect.innerHTML = '<option value="" disabled selected>-- Select Service --</option>';
        serviceRates.forEach(rate => {
            const opt = document.createElement('option');
            opt.value = rate.id;
            opt.textContent = `${rate.name} (Fee: ₹${rate.customerFee})`;
            qCustServiceSelect.appendChild(opt);
        });
        const customOpt = document.createElement('option');
        customOpt.value = 'custom';
        customOpt.textContent = 'Other / Custom Service';
        qCustServiceSelect.appendChild(customOpt);

        if (currentSel) {
            qCustServiceSelect.value = currentSel;
        }
    }

    // Bind dashboard select change
    if (qCustServiceSelect) {
        qCustServiceSelect.addEventListener('change', () => {
            const val = qCustServiceSelect.value;
            if (val === 'custom') {
                qCustServiceManualGroup.style.display = 'block';
                qCustCharge.value = '';
                qCustPaid.value = '';
                updateDashboardCalculatedIndicators(0, 0, 0);
            } else {
                qCustServiceManualGroup.style.display = 'none';
                const service = serviceRates.find(r => r.id === val);
                if (service) {
                    qCustCharge.value = service.customerFee;
                    qCustPaid.value = service.customerFee;
                    updateDashboardCalculatedIndicators(service.customerFee, service.customerFee, service.netMargin);
                }
            }
        });
    }

    function recalculateDashboardForm() {
        const charge = parseFloat(qCustCharge.value) || 0;
        const paid = parseFloat(qCustPaid.value) || 0;

        let commission = 0;
        const val = qCustServiceSelect.value;
        if (val && val !== 'custom') {
            const service = serviceRates.find(r => r.id === val);
            if (service) {
                commission = Math.max(0, paid - service.govtFee);
            }
        } else {
            commission = paid;
        }

        updateDashboardCalculatedIndicators(charge, paid, commission);
    }

    function updateDashboardCalculatedIndicators(charge, paid, commission) {
        const dues = Math.max(0, charge - paid);
        if (qCustDuesLbl) qCustDuesLbl.textContent = `₹${dues.toFixed(2)}`;
        if (qCustCommLbl) qCustCommLbl.textContent = `₹${commission.toFixed(2)}`;
    }

    if (qCustCharge) qCustCharge.addEventListener('input', recalculateDashboardForm);
    if (qCustPaid) qCustPaid.addEventListener('input', recalculateDashboardForm);

    // Save Quick Transaction
    if (qSaveTxBtn) {
        qSaveTxBtn.addEventListener('click', () => {
            const amount = parseFloat(qTxAmount.value);
            if (!amount || amount <= 0) {
                alert('Please enter a valid amount.');
                return;
            }

            const type = qTxType.value;
            const category = qTxCategory.value;
            const mode = qTxMode.value;
            const desc = qTxDesc.value.trim() || `Quick ${type} entry`;
            const customTxDate = qTxDateInput ? qTxDateInput.value : '';
            const linkId = Date.now().toString() + Math.random().toString(36).substr(2, 5);

            addTransactionDirectly(type, category, amount, mode, desc, customTxDate);

            // Link it
            if (transactions.length > 0) {
                transactions[0].id = linkId;
                saveTransactions();
            }


            qTxAmount.value = '';
            qTxDesc.value = '';
            if (qTxDateInput) qTxDateInput.value = getLocalISODate();
            alert('Transaction saved successfully!');
            if (window.incrementProcessedCount) window.incrementProcessedCount();
            updateQuickRecentLogs();
        });
    }

    // Save Quick Customer Record
    if (qSaveCustBtn) {
        qSaveCustBtn.addEventListener('click', () => {
            const name = qCustName.value.trim();
            const phone = qCustPhone.value.trim();
            const serviceVal = qCustServiceSelect.value;
            const charge = parseFloat(qCustCharge.value) || 0;
            const paid = parseFloat(qCustPaid.value) || 0;
            const customCustDate = qCustDateInput ? qCustDateInput.value : '';

            if (!name) {
                alert('Please enter a Customer Name.');
                return;
            }

            if (!serviceVal) {
                alert('Please select a service.');
                return;
            }

            let serviceName = '';
            let govtFee = 0;
            let netMargin = 0;

            if (serviceVal === 'custom') {
                serviceName = qCustServiceManual.value.trim() || 'Custom Service';
                govtFee = 0;
                netMargin = charge;
            } else {
                const service = serviceRates.find(r => r.id === serviceVal);
                if (service) {
                    serviceName = service.name;
                    govtFee = service.govtFee;
                    netMargin = service.netMargin;
                }
            }

            const dues = Math.max(0, charge - paid);
            const status = dues <= 0 ? 'Paid' : 'Pending';

            const custIsoDate = customCustDate || getLocalISODate();
            let custFormattedDate;
            if (customCustDate) {
                const parts = customCustDate.split('-');
                const dObj = new Date(parts[0], parts[1] - 1, parts[2]);
                custFormattedDate = dObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
            } else {
                custFormattedDate = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
            }

            // Generate next customer number
            let custNo = 1001;
            if (customers.length > 0) {
                const nos = customers.map(c => c.custNo).filter(n => typeof n === 'number');
                if (nos.length > 0) {
                    custNo = Math.max(...nos) + 1;
                } else {
                    custNo = 1001 + customers.length;
                }
            }

            const address = qCustAddress ? qCustAddress.value.trim() : '';

            const workStatus = qCustWorkStatus ? qCustWorkStatus.value : 'Complete';
            const newCust = {
                id: Date.now().toString(),
                custNo,
                date: custFormattedDate,
                isoDate: custIsoDate,
                name,
                phone: phone || '-',
                address: address || '-',
                service: serviceName,
                charge,
                paid,
                dues,
                status,
                govtFee,
                workStatus
            };

            customers.unshift(newCust);

            // Log corresponding transaction in ledger
            if (paid > 0) {
                addTransactionDirectly('income', 'Service Charge', paid, 'Cash', `Cash from customer: ${name} (${serviceName})`, custIsoDate);
            }
            if (govtFee > 0) {
                const linkId = Date.now().toString() + Math.random().toString(36).substr(2, 5);
                addTransactionDirectly('expense', 'CSC Wallet', govtFee, 'CSC Wallet', `Govt Portal Fee debited: ${name} (${serviceName})`, custIsoDate);
                
                if (transactions.length > 0) {
                    transactions[0].id = linkId;
                    saveTransactions();
                }
                
                addWalletTransaction('debit', govtFee, `Govt Portal Fee (Quick): ${name} (${serviceName})`, custIsoDate, linkId);
            }

            saveCustomers();

            qCustName.value = '';
            qCustPhone.value = '';
            if (qCustAddress) qCustAddress.value = '';
            qCustServiceSelect.value = '';
            qCustServiceManual.value = '';
            qCustServiceManualGroup.style.display = 'none';
            qCustCharge.value = '';
            qCustPaid.value = '';
            if (qCustWorkStatus) qCustWorkStatus.value = 'Complete';
            if (qCustDateInput) qCustDateInput.value = getLocalISODate();
            updateDashboardCalculatedIndicators(0, 0, 0);

            if (window.incrementProcessedCount) window.incrementProcessedCount();
            updateQuickRecentLogs();

            setTimeout(() => {
                if (confirm(`Customer record logged successfully!\n\nDo you want to print a receipt for ${newCust.name}?`)) {
                    printServiceReceipt(newCust);
                }
                setTimeout(() => {
                    if (confirm(`Do you want to send the receipt to Customer: ${newCust.name} via WhatsApp?`)) {
                        sendWhatsAppReceipt(newCust);
                    }
                }, 100);
            }, 100);
        });
    }

    // 5c. Wallet Top-up Handler
    const walletTopupBtn = document.getElementById('wallet-topup-btn');
    const walletTopupAmount = document.getElementById('wallet-topup-amount');
    const walletTopupDate = document.getElementById('wallet-topup-date');
    const walletTopupSource = document.getElementById('wallet-topup-source');
    const walletTopupDesc = document.getElementById('wallet-topup-desc');

    if (walletTopupBtn) {
        walletTopupBtn.addEventListener('click', () => {
            const activeSession = JSON.parse(localStorage.getItem('csc_active_user'));
            if (activeSession && activeSession.role === 'Staff') {
                alert('Error: Staff users are not authorized to top-up the CSC Wallet.');
                return;
            }
            
            const amount = parseFloat(walletTopupAmount.value);
            if (!amount || amount <= 0) {
                alert('Please enter a valid top-up amount.');
                return;
            }

            const customDate = walletTopupDate ? walletTopupDate.value : '';
            const source = walletTopupSource.value;
            const notes = walletTopupDesc.value.trim();

            const wtxDesc = `Wallet Top-up (${source})${notes ? ': ' + notes : ''}`;

            // 1. Credit wallet
            addWalletTransaction('credit', amount, wtxDesc, customDate);

            // Reset inputs
            walletTopupAmount.value = '';
            walletTopupDesc.value = '';
            if (walletTopupDate) walletTopupDate.value = getLocalISODate();

            alert('Wallet loaded successfully!');
            if (window.incrementProcessedCount) window.incrementProcessedCount();
        });
    }

    // 5d. Staff Management Handler
    function initStaffManagement() {
        const staffTableBody = document.getElementById('staff-table-body');
        const addStaffForm = document.getElementById('add-staff-form');

        function loadStaffList() {
            if (!staffTableBody) return;
            
            const users = JSON.parse(localStorage.getItem('csc_users') || '[]');
            const activeUser = JSON.parse(localStorage.getItem('csc_active_user') || '{}');
            
            staffTableBody.innerHTML = '';
            
            if (users.length === 0) {
                staffTableBody.innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">No staff records found.</td>
                    </tr>
                `;
                return;
            }
            
            users.forEach(user => {
                const roleBadge = user.role === 'Owner'
                    ? `<span class="badge badge-role-owner"><i data-lucide="crown" style="width: 12px; height: 12px; vertical-align: middle; margin-right: 4px;"></i>Owner</span>`
                    : `<span class="badge badge-role-staff"><i data-lucide="user" style="width: 12px; height: 12px; vertical-align: middle; margin-right: 4px;"></i>Staff</span>`;
                
                const isSelf = user.id === activeUser.id;
                const isDefaultOwner = user.id === 'user_owner';
                
                // Disable delete for self and default owner
                const deleteButton = (isSelf || isDefaultOwner)
                    ? `<span style="color: var(--text-muted); font-size: 11px; font-weight: 600;">System Protected</span>`
                    : `<button class="table-action-btn del-btn del-staff-btn" data-id="${user.id}">Delete</button>`;
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td style="padding: 12px 16px; font-weight: 600; color: var(--text-main);">${user.name}</td>
                    <td style="padding: 12px 16px;">${roleBadge}</td>
                    <td style="padding: 12px 16px; color: var(--text-muted);">${user.mobile || '-'}</td>
                    <td style="padding: 12px 16px; text-align: center; font-family: monospace; letter-spacing: 2px; font-size: 14px;">••••</td>
                    <td style="padding: 12px 16px; text-align: center;">${deleteButton}</td>
                `;
                
                // Add delete click handler if button exists
                const delBtn = row.querySelector('.del-staff-btn');
                if (delBtn) {
                    delBtn.addEventListener('click', () => {
                        if (confirm(`Are you sure you want to delete staff account: "${user.name}"?`)) {
                            let currentUsers = JSON.parse(localStorage.getItem('csc_users') || '[]');
                            currentUsers = currentUsers.filter(u => u.id !== user.id);
                            localStorage.setItem('csc_users', JSON.stringify(currentUsers));
                            loadStaffList();
                        }
                    });
                }
                
                staffTableBody.appendChild(row);
            });
            
            if (window.lucide) lucide.createIcons();
        }

        if (addStaffForm) {
            addStaffForm.addEventListener('submit', (e) => {
                e.preventDefault();
                
                const name = document.getElementById('staff-name').value.trim();
                const mobile = document.getElementById('staff-mobile').value.trim();
                const pin = document.getElementById('staff-pin').value.trim();
                const role = document.getElementById('staff-role').value;
                
                if (pin.length !== 4 || isNaN(pin)) {
                    alert('Security PIN must be a 4-digit number.');
                    return;
                }
                
                let currentUsers = JSON.parse(localStorage.getItem('csc_users') || '[]');
                
                // Check if PIN already exists for this role
                const pinExists = currentUsers.some(u => u.role === role && u.pin === pin);
                if (pinExists) {
                    alert(`Error: A user with role "${role}" already uses this security PIN. Please choose a different PIN.`);
                    return;
                }
                
                const newUser = {
                    id: "user_" + Date.now().toString(),
                    name,
                    role,
                    pin,
                    mobile
                };
                
                currentUsers.push(newUser);
                localStorage.setItem('csc_users', JSON.stringify(currentUsers));
                
                // Reset inputs
                addStaffForm.reset();
                loadStaffList();
                
                alert('New staff member added successfully!');
            });
        }

        // Render initial list
        loadStaffList();
        
        // Make loadStaffList global so it can be called on user login/role switch
        window.loadStaffList = loadStaffList;
    }

    // 6. Initial Page Load
    loadLedger();
    loadCustomers();
    loadRates();
    populateServiceDropdown();
    populateDashboardServiceDropdown();
    updateQuickRecentLogs();
    loadWallet();
    window.loadWallet = loadWallet; // Expose globally for recharge manager
    initStaffManagement();
});

