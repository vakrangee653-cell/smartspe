// Resume & Marriage Biodata Builder Module

document.addEventListener('DOMContentLoaded', () => {
    // Tab switching logic inside form
    const tabs = document.querySelectorAll('.form-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const targetTabId = tab.getAttribute('data-tab');
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(content => {
                content.style.display = 'none';
            });

            document.getElementById(targetTabId).style.display = 'flex';
        });
    });

    // References to inputs
    const inputs = [
        'bio-fullname', 'bio-dob', 'bio-email', 'bio-phone', 'bio-address',
        'bio-height', 'bio-complexion', 'bio-father', 'bio-father-occ',
        'bio-mother', 'bio-siblings', 'bio-tob', 'bio-pob', 'bio-gotra',
        'bio-manglik', 'bio-education', 'bio-college', 'bio-occupation',
        'bio-income', 'bio-skills', 'bio-experience'
    ];

    const templateSelect = document.getElementById('biodata-template-type');
    const previewContainer = document.getElementById('screen-preview-container');
    const printBtn = document.getElementById('print-biodata');

    // Add event listeners to all fields for real-time rendering
    inputs.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', renderBiodata);
            el.addEventListener('change', renderBiodata);
        }
    });

    templateSelect.addEventListener('change', renderBiodata);

    function renderBiodata() {
        const template = templateSelect.value;
        
        // Grab values
        const data = {};
        inputs.forEach(id => {
            const el = document.getElementById(id);
            data[id] = el ? el.value.trim() : '';
        });

        // Format Date nicely
        let formattedDob = '';
        if (data['bio-dob']) {
            const dateObj = new Date(data['bio-dob']);
            formattedDob = dateObj.toLocaleDateString('en-IN', {
                day: 'numeric', month: 'long', year: 'numeric'
            });
        }

        let htmlContent = '';

        if (template === 'traditional') {
            // Traditional Hindu Marriage Biodata Template
            htmlContent = `
                <div class="biodata-traditional">
                    <div class="biodata-traditional-header">
                        <div class="shree-ganesh-icon">॥ श्री गणेशाय नमः ॥</div>
                        <h2 class="biodata-traditional-title">Biodata</h2>
                    </div>

                    <div class="traditional-section">
                        <h4 class="traditional-section-title">Personal Details</h4>
                        <div class="traditional-grid">
                            <span class="traditional-label">Name:</span>
                            <span>${data['bio-fullname'] || 'Ramesh Kumar'}</span>
                            
                            <span class="traditional-label">Date of Birth:</span>
                            <span>${formattedDob || '15th August 1995'}</span>

                            <span class="traditional-label">Height:</span>
                            <span>${data['bio-height'] || '5 ft 8 in'}</span>

                            <span class="traditional-label">Complexion:</span>
                            <span>${data['bio-complexion'] || 'Fair'}</span>
                        </div>
                    </div>

                    <div class="traditional-section">
                        <h4 class="traditional-section-title">Horoscope Details</h4>
                        <div class="traditional-grid">
                            <span class="traditional-label">Time of Birth:</span>
                            <span>${data['bio-tob'] || '04:30 AM'}</span>

                            <span class="traditional-label">Place of Birth:</span>
                            <span>${data['bio-pob'] || 'Jaipur, Rajasthan'}</span>

                            <span class="traditional-label">Gotra / Rashi:</span>
                            <span>${data['bio-gotra'] || 'Kaushik / Mesh'}</span>

                            <span class="traditional-label">Manglik:</span>
                            <span>${data['bio-manglik'] || 'No'}</span>
                        </div>
                    </div>

                    <div class="traditional-section">
                        <h4 class="traditional-section-title">Education & Profession</h4>
                        <div class="traditional-grid">
                            <span class="traditional-label">Education:</span>
                            <span>${data['bio-education'] || 'B.Tech in Computer Science'}</span>

                            <span class="traditional-label">College/Univ:</span>
                            <span>${data['bio-college'] || 'Rajasthan Technical University'}</span>

                            <span class="traditional-label">Occupation:</span>
                            <span>${data['bio-occupation'] || 'Software Engineer at TCS'}</span>

                            <span class="traditional-label">Annual Income:</span>
                            <span>${data['bio-income'] || '8 Lakhs Per Annum'}</span>
                        </div>
                    </div>

                    <div class="traditional-section">
                        <h4 class="traditional-section-title">Family Background</h4>
                        <div class="traditional-grid">
                            <span class="traditional-label">Father's Name:</span>
                            <span>${data['bio-father'] || 'Sh. Suresh Kumar'}</span>

                            <span class="traditional-label">Father's Job:</span>
                            <span>${data['bio-father-occ'] || 'Retired Bank Manager'}</span>

                            <span class="traditional-label">Mother's Name:</span>
                            <span>${data['bio-mother'] || 'Smt. Kamla Devi'}</span>

                            <span class="traditional-label">Siblings:</span>
                            <span>${data['bio-siblings'] || '1 Younger Brother (Student)'}</span>
                        </div>
                    </div>

                    <div class="traditional-section">
                        <h4 class="traditional-section-title">Contact Information</h4>
                        <div class="traditional-grid">
                            <span class="traditional-label">Mobile No:</span>
                            <span>${data['bio-phone'] || '9876543210'}</span>

                            <span class="traditional-label">Address:</span>
                            <span>${data['bio-address'] || '102, Shanti Nagar, Mansarovar, Jaipur'}</span>
                        </div>
                    </div>
                </div>
            `;
        } else if (template === 'modern') {
            // Modern Dual-Pane Resume Template
            const skillsArr = data['bio-skills'] ? data['bio-skills'].split(',') : ['Typing', 'MS Excel', 'Customer Service'];
            const skillsHtml = skillsArr.map(s => `<div class="modern-left-contact-item">• ${s.trim()}</div>`).join('');

            htmlContent = `
                <div class="resume-modern">
                    <div class="modern-left-pane">
                        <div class="modern-avatar-placeholder"></div>
                        <h2 class="modern-left-name">${data['bio-fullname'] || 'RAMESH KUMAR'}</h2>
                        <div class="modern-left-title">${data['bio-occupation'] || 'DIGITAL OPERATOR'}</div>

                        <div class="modern-left-section">
                            <h4 class="modern-left-sectitle">Contact Info</h4>
                            <div class="modern-left-contact-item">📞 ${data['bio-phone'] || '9876543210'}</div>
                            <div class="modern-left-contact-item">✉️ ${data['bio-email'] || 'ramesh@gmail.com'}</div>
                            <div class="modern-left-contact-item">📍 ${data['bio-address'] || 'Jaipur, Rajasthan'}</div>
                        </div>

                        <div class="modern-left-section">
                            <h4 class="modern-left-sectitle">Education</h4>
                            <div class="modern-left-contact-item" style="font-weight: 600; color: white;">
                                ${data['bio-education'] || 'B.Tech / Graduate'}
                            </div>
                            <div class="modern-left-contact-item" style="font-size: 11px; color: #94a3b8;">
                                ${data['bio-college'] || 'Rajasthan Technical University'}
                            </div>
                        </div>

                        <div class="modern-left-section">
                            <h4 class="modern-left-sectitle">Key Skills</h4>
                            ${skillsHtml}
                        </div>
                    </div>

                    <div class="modern-right-pane">
                        <div class="modern-right-section">
                            <h4 class="modern-right-sectitle">Professional Summary</h4>
                            <p style="font-size: 14px; line-height: 1.6; color: #475569;">
                                Highly motivated and detailed-oriented professional. Experienced in handling citizen documentations, calculations, and general administrative services. Proven ability to assist customers efficiently with data entry, digital solutions, and online state portals.
                            </p>
                        </div>

                        <div class="modern-right-section">
                            <h4 class="modern-right-sectitle">Work Experience</h4>
                            <div class="modern-right-item">
                                <div class="modern-right-item-header">
                                    <span>${data['bio-occupation'] || 'Senior Digital Operator'}</span>
                                    <span>2023 - Present</span>
                                </div>
                                <div class="modern-right-item-sub">Apna Digital Kendra | Full Time</div>
                                <p style="font-size: 13px; line-height: 1.5; color: #475569;">
                                    ${data['bio-experience'] || 'Managed daily processing of government certificates (PAN, Aadhaar, Caste, Income). Handled financial bookkeeping and online applications for over 500+ clients with 99% accuracy.'}
                                </p>
                            </div>
                        </div>

                        <div class="modern-right-section">
                            <h4 class="modern-right-sectitle">Personal Details</h4>
                            <table style="width: 100%; border-collapse: collapse; font-size: 13px; color: #475569;">
                                <tr>
                                    <td style="padding: 6px 0; font-weight: bold; width: 140px;">Date of Birth:</td>
                                    <td>${formattedDob || '15 August 1995'}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-weight: bold;">Father's Name:</td>
                                    <td>${data['bio-father'] || 'Sh. Suresh Kumar'}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-weight: bold;">Languages Known:</td>
                                    <td>Hindi, English</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // Classic Minimalist Resume Template (Black & White style)
            htmlContent = `
                <div class="resume-classic">
                    <div class="resume-classic-header">
                        <h2 class="resume-classic-name">${data['bio-fullname'] || 'RAMESH KUMAR'}</h2>
                        <div class="resume-classic-contact">
                            Mobile: ${data['bio-phone'] || '9876543210'} | Email: ${data['bio-email'] || 'ramesh@gmail.com'}
                            <br>Address: ${data['bio-address'] || 'Jaipur, Rajasthan'}
                        </div>
                    </div>

                    <div class="classic-section">
                        <h4 class="classic-title">Career Objective</h4>
                        <p style="font-size: 14px; line-height: 1.5;">
                            To secure a challenging role where I can utilize my administrative, document processing, and customer relationship management skills to contribute to organizational success and local community development.
                        </p>
                    </div>

                    <div class="classic-section">
                        <h4 class="classic-title">Academic Qualifications</h4>
                        <div class="classic-grid">
                            <div>
                                <div class="classic-item-header">
                                    <span>${data['bio-education'] || 'Bachelor of Science (B.Sc)'}</span>
                                    <span>Completed</span>
                                </div>
                                <div style="font-size: 13px; color: #555; margin-top: 4px;">
                                    College: ${data['bio-college'] || 'Rajasthan University'}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="classic-section">
                        <h4 class="classic-title">Professional Experience</h4>
                        <div class="classic-grid">
                            <div>
                                <div class="classic-item-header">
                                    <span>Job Title: ${data['bio-occupation'] || 'CSC VLE Operator'}</span>
                                    <span>Duration: 2 Years</span>
                                </div>
                                <p style="font-size: 13px; margin-top: 6px; line-height: 1.4;">
                                    ${data['bio-experience'] || 'Responsible for executing and submitting e-governance forms, resizing documents under strict parameters, generating financial bills, and guiding customers through online portal registrations.'}
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="classic-section">
                        <h4 class="classic-title">Skills Inventory</h4>
                        <p style="font-size: 13px; line-height: 1.5;">
                            <strong>Technical Skills:</strong> ${data['bio-skills'] || 'Data Entry, Document Optimization, MS Office Suite, Internet Utilities, E-Commerce transactions'}.
                        </p>
                    </div>

                    <div class="classic-section">
                        <h4 class="classic-title">Personal Information</h4>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
                            <div><strong>Date of Birth:</strong> ${formattedDob || '15-Aug-1995'}</div>
                            <div><strong>Father's Name:</strong> ${data['bio-father'] || 'Sh. Suresh Kumar'}</div>
                            <div><strong>Mother's Name:</strong> ${data['bio-mother'] || 'Smt. Kamla Devi'}</div>
                            <div><strong>Marital Status:</strong> Single / Married</div>
                        </div>
                    </div>
                </div>
            `;
        }

        // Render to screen preview
        previewContainer.innerHTML = htmlContent;
    }

    // Trigger Initial Render
    renderBiodata();

    // Print Handler
    printBtn.addEventListener('click', () => {
        const template = templateSelect.value;
        const screenContent = previewContainer.innerHTML;
        const printArea = document.getElementById('printable-area');

        printArea.innerHTML = screenContent;
        window.print();

        if (window.incrementProcessedCount) window.incrementProcessedCount();
    });
});
