// CSP Reports & Statement Generator Module

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const startDateInput = document.getElementById('rep-start-date');
    const endDateInput = document.getElementById('rep-end-date');

    const btnRepToday = document.getElementById('btn-rep-today');
    const btnRepWeek = document.getElementById('btn-rep-week');
    const btnRepMonth = document.getElementById('btn-rep-month');
    const btnRepAll = document.getElementById('btn-rep-all');

    const btnRepLedger = document.getElementById('btn-rep-ledger');
    const btnRepDues = document.getElementById('btn-rep-dues');
    const btnRepPL = document.getElementById('btn-rep-pl');

    const reportView = document.getElementById('report-screen-view');
    const printReportBtn = document.getElementById('print-report-btn');

    let currentReportType = null; // 'ledger', 'dues', 'pl'

    // Helper to get local date ISO string YYYY-MM-DD
    function getLocalISODate(dateObj = new Date()) {
        const year = dateObj.getFullYear();
        const month = String(dateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dateObj.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Set Default Dates: Start Date as 30 days ago, End Date as Today
    const todayStr = getLocalISODate();
    const past30Days = new Date();
    past30Days.setDate(past30Days.getDate() - 30);
    const past30DaysStr = getLocalISODate(past30Days);

    if (startDateInput) startDateInput.value = past30DaysStr;
    if (endDateInput) endDateInput.value = todayStr;

    // Quick range event listeners
    btnRepToday.addEventListener('click', () => {
        startDateInput.value = todayStr;
        endDateInput.value = todayStr;
        triggerReportRefresh();
    });

    btnRepWeek.addEventListener('click', () => {
        const past7 = new Date();
        past7.setDate(past7.getDate() - 7);
        startDateInput.value = getLocalISODate(past7);
        endDateInput.value = todayStr;
        triggerReportRefresh();
    });

    btnRepMonth.addEventListener('click', () => {
        const firstDay = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        startDateInput.value = getLocalISODate(firstDay);
        endDateInput.value = todayStr;
        triggerReportRefresh();
    });

    btnRepAll.addEventListener('click', () => {
        startDateInput.value = '';
        endDateInput.value = '';
        triggerReportRefresh();
    });

    // Date inputs change trigger report regeneration
    startDateInput.addEventListener('change', triggerReportRefresh);
    endDateInput.addEventListener('change', triggerReportRefresh);

    function triggerReportRefresh() {
        if (currentReportType) {
            generateReport(currentReportType);
        }
    }

    // Report Type Triggers
    btnRepLedger.addEventListener('click', () => generateReport('ledger'));
    btnRepDues.addEventListener('click', () => generateReport('dues'));
    btnRepPL.addEventListener('click', () => generateReport('pl'));

    function getFilteredData() {
        const txs = JSON.parse(localStorage.getItem('csc_csp_transactions') || '[]');
        const custs = JSON.parse(localStorage.getItem('csc_csp_customers') || '[]');

        const start = startDateInput.value;
        const end = endDateInput.value;

        // Filtering Transactions
        const filteredTxs = txs.filter(tx => {
            const date = tx.isoDate || todayStr; // fallback for legacy entries
            if (start && date < start) return false;
            if (end && date > end) return false;
            return true;
        });

        // Filtering Customers
        const filteredCusts = custs.filter(c => {
            const date = c.isoDate || todayStr; // fallback
            if (start && date < start) return false;
            if (end && date > end) return false;
            return true;
        });

        return { filteredTxs, filteredCusts, start, end };
    }

    function generateReport(type) {
        currentReportType = type;
        const { filteredTxs, filteredCusts, start, end } = getFilteredData();

        // Format dates for headings
        const dateHeading = (start || end) 
            ? `Statement Period: ${start ? formatDate(start) : 'Beginning'} to ${end ? formatDate(end) : 'Today'}`
            : `All-Time Business Statement`;

        let html = '';

        if (type === 'ledger') {
            html = buildLedgerReport(filteredTxs, dateHeading);
        } else if (type === 'dues') {
            html = buildDuesReport(filteredCusts, dateHeading);
        } else if (type === 'pl') {
            html = buildPLReport(filteredTxs, filteredCusts, dateHeading);
        }

        reportView.innerHTML = html;
        printReportBtn.removeAttribute('disabled');
        lucide.createIcons();
    }

    function formatDate(dateStr) {
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    }

    // Report Compilers
    function buildLedgerReport(txs, dateHeading) {
        let totalIncome = 0;
        let totalExpense = 0;

        const rows = txs.map((tx, idx) => {
            if (tx.type === 'income') totalIncome += tx.amount;
            else totalExpense += tx.amount;

            return `
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1;">${tx.date}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; font-weight: bold; color: ${tx.type === 'income' ? '#10b981' : '#ef4444'};">
                        ${tx.type.toUpperCase()}
                    </td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1;">${tx.category}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; color: #555;">${tx.desc}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; text-align: right; font-weight: bold;">₹${tx.amount.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        const netBalance = totalIncome - totalExpense;

        return `
            <div class="invoice-print-container" style="color: #111827;">
                <div style="text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 20px;">
                    <h2 style="font-size: 22px; font-weight: 800;">Apna Digital CSC Center</h2>
                    <h3 style="font-size: 15px; font-weight: 700; color: #475569; text-transform: uppercase; margin-top: 4px;">Ledger Statement</h3>
                    <p style="font-size: 12px; color: #64748b; margin-top: 6px;">${dateHeading}</p>
                </div>

                <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 13px;">
                    <thead>
                        <tr style="background-color: #f1f5f9; text-align: left; font-weight: 700;">
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Date</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Type</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Category</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Description</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1; text-align: right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.length > 0 ? rows : '<tr><td colspan="5" style="text-align: center; padding: 30px; color: #64748b;">No transaction data found for this period.</td></tr>'}
                    </tbody>
                </table>

                <div style="margin-left: auto; width: 300px; border-top: 2px solid #0f172a; padding-top: 15px; font-size: 14px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                        <span>Total Cash Received (Income):</span>
                        <span style="font-weight: bold; color: #10b981;">₹${totalIncome.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                        <span>Total Cash Spent (Expense):</span>
                        <span style="font-weight: bold; color: #ef4444;">₹${totalExpense.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 16px; border-top: 1px solid #e2e8f0; padding-top: 8px;">
                        <span>Net Balance Profit:</span>
                        <span style="color: ${netBalance >= 0 ? '#10b981' : '#ef4444'};">₹${netBalance.toFixed(2)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    function buildDuesReport(custs, dateHeading) {
        const duesCusts = custs.filter(c => c.dues > 0);
        let totalDues = 0;

        const rows = duesCusts.map((c, idx) => {
            totalDues += c.dues;
            return `
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1;">${c.date}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1;">
                        <strong>${c.name}</strong><br>
                        <span style="font-size: 11px; color: #555;">Mob: ${c.phone}</span>
                    </td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; font-size: 12px;">${c.address || '-'}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1;">${c.service}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; text-align: right;">₹${c.charge.toFixed(2)}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; text-align: right; color: #10b981;">₹${c.paid.toFixed(2)}</td>
                    <td style="padding: 10px; border-bottom: 1px solid #cbd5e1; text-align: right; font-weight: bold; color: #f59e0b;">₹${c.dues.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        return `
            <div class="invoice-print-container" style="color: #111827;">
                <div style="text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 20px;">
                    <h2 style="font-size: 22px; font-weight: 800;">Apna Digital CSC Center</h2>
                    <h3 style="font-size: 15px; font-weight: 700; color: #475569; text-transform: uppercase; margin-top: 4px;">Pending Customer Dues Statement</h3>
                    <p style="font-size: 12px; color: #64748b; margin-top: 6px;">${dateHeading}</p>
                </div>

                <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 13px;">
                    <thead>
                        <tr style="background-color: #f1f5f9; text-align: left; font-weight: 700;">
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Date</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Customer</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Address</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1;">Service Availed</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1; text-align: right;">Total Charge</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1; text-align: right;">Paid Amt</th>
                            <th style="padding: 12px; border: 1px solid #cbd5e1; text-align: right;">Pending Dues</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.length > 0 ? rows : '<tr><td colspan="7" style="text-align: center; padding: 30px; color: #64748b;">No pending customer dues found for this period.</td></tr>'}
                    </tbody>
                </table>

                <div style="margin-left: auto; width: 300px; border-top: 2px solid #0f172a; padding-top: 15px; font-size: 14px;">
                    <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 16px; color: #f59e0b;">
                        <span>Total Pending Balance:</span>
                        <span>₹${totalDues.toFixed(2)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    function buildPLReport(txs, custs, dateHeading) {
        let totalRevenue = 0;   // Paid cash from customer billing
        let portalWalletDeductions = 0; // Govt fees charged on wallet
        let operatingExpenses = {
            salary: 0,
            advance: 0,
            stationery: 0,
            electricity: 0,
            rent: 0,
            other: 0
        };

        // 1. Process customer collection revenue & portal expense deductions from wallet
        custs.forEach(c => {
            totalRevenue += c.paid;
            portalWalletDeductions += (c.govtFee || 0);
        });

        // 2. Process ledger transaction costs
        txs.forEach(tx => {
            // Check only expenses logged in ledger
            if (tx.type === 'expense') {
                const cat = tx.category.toLowerCase();
                const amt = tx.amount;

                // Sort ledger operating costs
                if (cat.includes('salary')) {
                    operatingExpenses.salary += amt;
                } else if (cat.includes('advance')) {
                    operatingExpenses.advance += amt;
                } else if (cat.includes('stationery') || cat.includes('paper')) {
                    operatingExpenses.stationery += amt;
                } else if (cat.includes('electricity') || cat.includes('internet')) {
                    operatingExpenses.electricity += amt;
                } else if (cat.includes('rent')) {
                    operatingExpenses.rent += amt;
                } else if (cat.includes('wallet')) {
                    // Govt wallet fees are already summed in portalWalletDeductions, skip ledger duplicate
                } else {
                    operatingExpenses.other += amt;
                }
            } else {
                // If it is a manual ledger income (e.g. commission or general cash), add to total revenue
                // but exclude customer service charge to prevent double-counting customer payments
                if (!tx.desc.includes('customer:')) {
                    totalRevenue += tx.amount;
                }
            }
        });

        const grossMargin = totalRevenue - portalWalletDeductions;
        const totalOperatingCosts = Object.values(operatingExpenses).reduce((a, b) => a + b, 0);
        const netProfit = grossMargin - totalOperatingCosts;

        return `
            <div class="invoice-print-container" style="color: #111827;">
                <div style="text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 20px;">
                    <h2 style="font-size: 22px; font-weight: 800;">Apna Digital CSC Center</h2>
                    <h3 style="font-size: 15px; font-weight: 700; color: #475569; text-transform: uppercase; margin-top: 4px;">Profit & Loss Statement (P&L)</h3>
                    <p style="font-size: 12px; color: #64748b; margin-top: 6px;">${dateHeading}</p>
                </div>

                <div style="display: flex; flex-direction: column; gap: 14px; font-size: 14px;">
                    <!-- A. Revenue -->
                    <div style="border-bottom: 1px solid #cbd5e1; padding-bottom: 6px; font-weight: bold; display: flex; justify-content: space-between; font-size: 15px;">
                        <span>1. Total Cash Revenue (Gross Sales)</span>
                        <span style="color: #10b981;">₹${totalRevenue.toFixed(2)}</span>
                    </div>

                    <!-- B. Portal Wallet Costs -->
                    <div style="display: flex; justify-content: space-between; padding-left: 20px; color: #4b5563;">
                        <span>Less: Government Portal Fees (CSC Wallet debits)</span>
                        <span>₹${portalWalletDeductions.toFixed(2)}</span>
                    </div>

                    <!-- C. Gross Margin -->
                    <div style="border-bottom: 2px solid #0f172a; padding: 6px 0; font-weight: bold; display: flex; justify-content: space-between; font-size: 15px; background-color: #f8fafc;">
                        <span>2. Gross Commission Profit (Margin)</span>
                        <span>₹${grossMargin.toFixed(2)}</span>
                    </div>

                    <!-- D. Operating Expenses -->
                    <div style="font-weight: bold; font-size: 15px; margin-top: 10px;">
                        <span>3. Operating Expenditures (Business Expenses)</span>
                    </div>
                    
                    <div style="padding-left: 20px; display: flex; flex-direction: column; gap: 8px; color: #4b5563;">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Shop Rental Cost:</span>
                            <span>₹${operatingExpenses.rent.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Staff Salaries:</span>
                            <span>₹${operatingExpenses.salary.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Staff Advances / Loans:</span>
                            <span>₹${operatingExpenses.advance.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Stationery / Xerox Paper:</span>
                            <span>₹${operatingExpenses.stationery.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Electricity & Internet bills:</span>
                            <span>₹${operatingExpenses.electricity.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Miscellaneous Expenses:</span>
                            <span>₹${operatingExpenses.other.toFixed(2)}</span>
                        </div>
                    </div>

                    <!-- Total expenses -->
                    <div style="border-bottom: 1px solid #cbd5e1; padding: 6px 0 6px 20px; font-weight: bold; display: flex; justify-content: space-between; color: #ef4444;">
                        <span>Total Operating Cost:</span>
                        <span>₹${totalOperatingCosts.toFixed(2)}</span>
                    </div>

                    <!-- E. Net Profit -->
                    <div style="border-top: 3px double #0f172a; border-bottom: 3px double #0f172a; padding: 12px 0; font-weight: 800; display: flex; justify-content: space-between; font-size: 18px; margin-top: 15px; background-color: #f1f5f9;">
                        <span>NET BUSINESS PROFIT:</span>
                        <span style="color: ${netProfit >= 0 ? '#10b981' : '#ef4444'};">₹${netProfit.toFixed(2)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    // Print Button
    printReportBtn.addEventListener('click', () => {
        const content = reportView.innerHTML;
        const printArea = document.getElementById('printable-area');

        printArea.innerHTML = content;
        window.print();

        if (window.incrementProcessedCount) window.incrementProcessedCount();
    });
});
